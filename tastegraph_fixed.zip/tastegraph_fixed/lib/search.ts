import { prisma } from "@/lib/prisma"
import { normalizeTags } from "@/lib/utils"

export type SortBy = "relevance" | "recent" | "saves"

export interface SearchOptions {
  q?: string
  tag?: string
  sortBy?: SortBy
  cursor?: string   // createdAt ISO for pagination
  take?: number
}

export interface SearchResult {
  id: string
  title: string
  slug: string
  description: string
  imageUrl: string
  width: number
  height: number
  tags: string[]
  saveCount: number
  createdAt: Date
  author: { id: string; username: string; name: string; image: string | null }
}

/**
 * Full-text search using PostgreSQL's built-in ts_vector/ts_query.
 * Falls back to ILIKE for non-PostgreSQL (dev / SQLite).
 */
export async function searchPins(opts: SearchOptions): Promise<{ items: SearchResult[]; hasMore: boolean; nextCursor: string | null }> {
  const { q = "", tag = "", sortBy = "relevance", cursor, take = 20 } = opts
  const query = q.trim().toLowerCase()
  const tagFilter = tag.trim().toLowerCase()

  // ── PostgreSQL full-text search ───────────────────────────────────────────
  if (query) {
    // Convert query to tsquery: "chocolate cake" → "chocolate & cake"
    const tsQuery = query
      .split(/\s+/)
      .filter(Boolean)
      .map((word) => `${word}:*`)   // prefix matching
      .join(" & ")

    try {
      // Raw SQL for full-text relevance ranking
      const rows: any[] = await prisma.$queryRaw`
        SELECT
          p.id,
          p.title,
          p.slug,
          p.description,
          p."imageUrl",
          p.width,
          p.height,
          p.tags,
          p."isHidden",
          p."createdAt",
          p."authorId",
          u.id           AS "author_id",
          u.username     AS "author_username",
          u.name         AS "author_name",
          u.image        AS "author_image",
          COUNT(s.id)    AS "saveCount",
          ts_rank(
            to_tsvector('english', p.title || ' ' || p.description || ' ' || p.tags),
            to_tsquery('english', ${tsQuery})
          ) AS rank
        FROM "Pin" p
        JOIN "User" u ON u.id = p."authorId"
        LEFT JOIN "Save" s ON s."pinId" = p.id
        WHERE
          p."isHidden" = false
          AND to_tsvector('english', p.title || ' ' || p.description || ' ' || p.tags)
              @@ to_tsquery('english', ${tsQuery})
          ${tagFilter ? Prisma.sql`AND lower(p.tags) LIKE ${'%' + tagFilter + '%'}` : Prisma.empty}
          ${cursor ? Prisma.sql`AND p."createdAt" < ${new Date(cursor)}` : Prisma.empty}
        GROUP BY p.id, u.id
        ORDER BY ${sortBy === "relevance" ? Prisma.sql`rank DESC, p."createdAt" DESC`
                 : sortBy === "saves"     ? Prisma.sql`"saveCount" DESC, p."createdAt" DESC`
                                          : Prisma.sql`p."createdAt" DESC`}
        LIMIT ${take + 1}
      `

      const hasMore = rows.length > take
      const items = rows.slice(0, take).map(rowToResult)
      return { items, hasMore, nextCursor: hasMore ? items[items.length - 1].createdAt.toISOString() : null }
    } catch {
      // Fallback to ILIKE if raw SQL fails (e.g. SQLite in dev)
    }
  }

  // ── Prisma fallback (ILIKE or in-memory) ─────────────────────────────────
  const where: any = { isHidden: false }
  if (cursor) where.createdAt = { lt: new Date(cursor) }

  // Tag filter via Prisma contains
  if (tagFilter) where.tags = { contains: tagFilter }

  // For keyword search without raw SQL, use OR across fields
  if (query) {
    where.OR = [
      { title:       { contains: query, mode: "insensitive" } },
      { description: { contains: query, mode: "insensitive" } },
      { tags:        { contains: query, mode: "insensitive" } },
    ]
  }

  const orderBy: any =
    sortBy === "saves"  ? [{ saves: { _count: "desc" } }, { createdAt: "desc" }]
                        : { createdAt: "desc" }

  const rows = await prisma.pin.findMany({
    where,
    orderBy,
    take: take + 1,
    include: { author: true, _count: { select: { saves: true } } },
  })

  const hasMore = rows.length > take
  const items: SearchResult[] = rows.slice(0, take).map((pin) => ({
    id: pin.id,
    title: pin.title,
    slug: pin.slug,
    description: pin.description,
    imageUrl: pin.imageUrl,
    width: pin.width,
    height: pin.height,
    tags: normalizeTags(pin.tags),
    saveCount: pin._count.saves,
    createdAt: pin.createdAt,
    author: {
      id: pin.author.id,
      username: pin.author.username,
      name: pin.author.name ?? pin.author.username,
      image: pin.author.image ?? null,
    },
  }))

  return { items, hasMore, nextCursor: hasMore ? items[items.length - 1].createdAt.toISOString() : null }
}

function rowToResult(row: any): SearchResult {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    description: row.description,
    imageUrl: row.imageUrl,
    width: row.width,
    height: row.height,
    tags: normalizeTags(row.tags),
    saveCount: Number(row.saveCount ?? 0),
    createdAt: row.createdAt,
    author: {
      id: row.author_id,
      username: row.author_username,
      name: row.author_name ?? row.author_username,
      image: row.author_image ?? null,
    },
  }
}

// Need Prisma namespace for raw SQL helpers
import { Prisma } from "@prisma/client"

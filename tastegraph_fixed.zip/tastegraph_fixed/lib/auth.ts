import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import GoogleProvider from "next-auth/providers/google"
import GitHubProvider from "next-auth/providers/github"
import bcrypt from "bcryptjs"
import { prisma } from "@/lib/prisma"

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/auth/sign-in" },

  providers: [
    // ── Google OAuth ─────────────────────────────────────────────────────
    ...(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
      ? [GoogleProvider({
          clientId:     process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        })]
      : []),

    // ── GitHub OAuth ─────────────────────────────────────────────────────
    ...(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET
      ? [GitHubProvider({
          clientId:     process.env.GITHUB_CLIENT_ID,
          clientSecret: process.env.GITHUB_CLIENT_SECRET,
        })]
      : []),

    // ── Credentials ──────────────────────────────────────────────────────
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email:    { label: "Email",    type: "email"    },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null
        const user = await prisma.user.findUnique({ where: { email: credentials.email } })
        if (!user || !user.password) return null
        const valid = await bcrypt.compare(credentials.password, user.password)
        if (!valid) return null
        return { id: user.id, email: user.email, name: user.name ?? user.username, image: user.image ?? undefined, role: user.role }
      },
    }),
  ],

  callbacks: {
    // ── OAuth sign-in: upsert user in DB ─────────────────────────────────
    async signIn({ user, account }) {
      if (account?.provider === "google" || account?.provider === "github") {
        if (!user.email) return false
        const email = user.email.toLowerCase()

        const existing = await prisma.user.findUnique({ where: { email } })
        if (!existing) {
          // Generate a unique username from email
          const base = email.split("@")[0].replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 18) || "user"
          let username = base
          let n = 0
          while (await prisma.user.findUnique({ where: { username } })) {
            n++
            username = `${base}${n}`
          }
          await prisma.user.create({
            data: {
              email,
              username,
              name:     user.name  ?? username,
              image:    user.image ?? null,
              password: "",           // no password for OAuth users
              role:     "user",
            },
          })
        } else if (user.image && !existing.image) {
          // Update avatar if missing
          await prisma.user.update({ where: { email }, data: { image: user.image } })
        }
      }
      return true
    },

    async jwt({ token, user, account }) {
      if (user) {
        // On first sign-in, look up DB user to get id + role
        const dbUser = await prisma.user.findUnique({ where: { email: user.email! } })
        token.id   = dbUser?.id   ?? user.id
        token.role = dbUser?.role ?? "user"
      }
      return token
    },

    async session({ session, token }) {
      if (session.user) {
        session.user.id   = String(token.id)
        session.user.role = String(token.role ?? "user")
      }
      return session
    },
  },
}

import { prisma } from "@/lib/prisma"

type NotifType = "like" | "comment" | "reply" | "follow" | "save"

interface CreateNotifArgs {
  type: NotifType
  userId: string   // receiver
  actorId: string  // who triggered
  pinId?: string
  commentId?: string
  message?: string
}

/**
 * Creates a notification. Silently no-ops if:
 *  - actor === receiver (no self-notifications)
 *  - an identical unread notification already exists (dedup within 1 hour)
 */
export async function createNotification({ type, userId, actorId, pinId, commentId, message }: CreateNotifArgs) {
  if (userId === actorId) return   // never self-notify

  // Dedup: skip if same unread notif exists in last hour
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000)
  const existing = await prisma.notification.findFirst({
    where: { type, userId, actorId, pinId: pinId ?? null, read: false, createdAt: { gte: oneHourAgo } },
  })
  if (existing) return

  await prisma.notification.create({
    data: { type, userId, actorId, pinId: pinId ?? null, commentId: commentId ?? null, message: message ?? null },
  })
}

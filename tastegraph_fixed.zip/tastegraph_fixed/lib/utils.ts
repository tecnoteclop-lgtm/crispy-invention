import { clsx } from "clsx"
export function cn(...inputs: Array<string | false | null | undefined>) {
  return clsx(inputs)
}
export function normalizeTags(tags: string) {
  return tags.split(",").map((tag) => tag.trim().toLowerCase()).filter(Boolean)
}

import { unstable_cache } from "next/cache"
import { getPins, getRecommendedPins, getTrendingTags, getBoards } from "@/lib/db-queries"

/**
 * Cache tags — call revalidateTag(tag) after mutations to bust the right caches.
 *
 *   revalidateTag("pins")    — after pin create / hide / delete
 *   revalidateTag("boards")  — after board create / update / delete
 *   revalidateTag("tags")    — after pin create / delete
 */

/** All public pins — cache 60 s, bust on "pins" tag */
export const getCachedPins = unstable_cache(
  async () => getPins(),
  ["pins-all"],
  { revalidate: 60, tags: ["pins"] }
)

/** Trending tags — cache 5 min */
export const getCachedTrendingTags = unstable_cache(
  async () => getTrendingTags(),
  ["trending-tags"],
  { revalidate: 300, tags: ["tags"] }
)

/** Recommended pins — cache 2 min */
export const getCachedRecommendedPins = unstable_cache(
  async () => getRecommendedPins(),
  ["recommended-pins"],
  { revalidate: 120, tags: ["pins"] }
)

/** Public boards — cache 2 min */
export const getCachedBoards = unstable_cache(
  async () => getBoards(),
  ["boards-public"],
  { revalidate: 120, tags: ["boards"] }
)

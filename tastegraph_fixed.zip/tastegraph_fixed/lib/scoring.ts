import { normalizeTags } from "@/lib/utils"

export type PinLike = { id: string; title: string; description: string; tags: string; createdAt: Date; saveCount?: number }

export function buildTasteProfile(savedPins: PinLike[]) {
  const counts = new Map<string, number>()
  for (const pin of savedPins) for (const tag of normalizeTags(pin.tags)) counts.set(tag, (counts.get(tag) ?? 0) + 1)
  const total = Array.from(counts.values()).reduce((a, b) => a + b, 0) || 1
  return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([tag, count]) => ({ tag, count, weight: Math.round((count / total) * 100) }))
}

export function scorePinForProfile(pin: PinLike, profile: Array<{ tag: string; count: number; weight: number }>) {
  const pinTags = new Set(normalizeTags(pin.tags))
  const tagScore = profile.reduce((sum, item) => sum + (pinTags.has(item.tag) ? item.weight : 0), 0)
  const popularityScore = Math.min((pin.saveCount ?? 0) * 4, 40)
  const freshnessBoost = 5
  return tagScore + popularityScore + freshnessBoost
}

export function similarityScore(aTags: string, bTags: string) {
  const a = new Set(normalizeTags(aTags))
  const b = new Set(normalizeTags(bTags))
  let overlap = 0
  for (const tag of a) if (b.has(tag)) overlap += 1
  return overlap
}

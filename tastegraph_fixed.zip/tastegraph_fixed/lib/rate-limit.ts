// Rate limiting with in-memory store.
// TODO for production: Replace with Redis/Upstash for multi-instance support.
// Each server instance has its own store; this works for single-instance deployments only.

interface RateLimitEntry {
  count: number
  resetAt: number
}

const store = new Map<string, RateLimitEntry>()

// Clean up expired entries periodically to prevent memory leaks
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now()
    for (const [key, entry] of store.entries()) {
      if (entry.resetAt < now) store.delete(key)
    }
  }, 60_000)
}

/**
 * Simple in-memory rate limiter.
 * @param key     Unique key per action + identifier (e.g. `register:${ip}`)
 * @param limit   Max requests allowed in the window (default 20)
 * @param windowMs Window size in ms (default 60 000 ms = 1 min)
 */
export function rateLimit(key: string, limit = 20, windowMs = 60_000) {
  const now = Date.now()
  const current = store.get(key)
  if (!current || current.resetAt < now) {
    store.set(key, { count: 1, resetAt: now + windowMs })
    return { allowed: true, remaining: limit - 1 }
  }
  if (current.count >= limit) {
    return { allowed: false, remaining: 0 }
  }
  current.count += 1
  store.set(key, current)
  return { allowed: true, remaining: limit - current.count }
}

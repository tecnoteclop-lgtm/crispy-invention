export async function track(eventName: string, page?: string, meta?: Record<string, unknown>) {
  try {
    await fetch("/api/analytics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ eventName, page, meta }),
    })
  } catch {
    // swallow client-side analytics errors
  }
}

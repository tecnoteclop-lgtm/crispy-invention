import { prisma } from "@/lib/prisma"
import { normalizeTags } from "@/lib/utils"
import { buildTasteProfile, scorePinForProfile, similarityScore } from "@/lib/scoring"

function mapPin(pin: any) {
  return {
    id: pin.id,
    title: pin.title,
    slug: pin.slug,
    description: pin.description,
    imageUrl: pin.imageUrl,
    width: pin.width,
    height: pin.height,
    tags: normalizeTags(pin.tags),
    rawTags: pin.tags,
    isHidden: pin.isHidden ?? false,
    saveCount: pin._count?.saves ?? 0,
    reportCount: pin._count?.reports ?? 0,
    createdAt: pin.createdAt,
    author: {
      id: pin.author.id,
      username: pin.author.username,
      name: pin.author.name ?? pin.author.username,
      // Use a local fallback instead of a hardcoded external URL
      image: pin.author.image ?? null,
    },
  }
}

export async function getPins(includeHidden = false) {
  const pins = await prisma.pin.findMany({
    where: includeHidden ? {} : { isHidden: false },
    orderBy: { createdAt: "desc" },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
  })
  return pins.map(mapPin)
}

export async function getPinBySlug(slug: string, includeHidden = false) {
  const pin = await prisma.pin.findFirst({
    where: includeHidden ? { slug } : { slug, isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
  })
  if (!pin) return null
  return mapPin(pin)
}

export async function getBoards(includePrivate = false) {
  const boards = await prisma.board.findMany({
    // FIX: Filter out private boards from public listings
    where: includePrivate ? {} : { isPrivate: false },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { saves: true } } },
  })
  return boards.map((board) => ({
    id: board.id,
    name: board.name,
    slug: board.slug,
    description: board.description ?? "",
    coverImage: board.coverImage ?? null,
    pinCount: board._count.saves,
  }))
}

export async function getUserBoards(userId: string) {
  const boards = await prisma.board.findMany({
    where: { ownerId: userId },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { saves: true } } },
  })
  return boards.map((board) => ({
    id: board.id,
    name: board.name,
    slug: board.slug,
    description: board.description ?? "",
    coverImage: board.coverImage ?? null,
    pinCount: board._count.saves,
  }))
}

export async function getTasteProfile(userId: string) {
  const saves = await prisma.save.findMany({
    where: { userId, pin: { isHidden: false } },
    include: { pin: true },
  })
  return buildTasteProfile(saves.map((save) => ({
    id: save.pin.id,
    title: save.pin.title,
    description: save.pin.description,
    tags: save.pin.tags,
    createdAt: save.pin.createdAt,
  })))
}

export async function getForYouPins(userId: string) {
  const profile = await getTasteProfile(userId)
  const allPins = await prisma.pin.findMany({
    where: { isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
  })
  return allPins
    .map((pin) => {
      const mapped = mapPin(pin)
      const score = scorePinForProfile(
        { id: pin.id, title: pin.title, description: pin.description, tags: pin.tags, createdAt: pin.createdAt, saveCount: pin._count.saves },
        profile
      )
      return { ...mapped, personalizedScore: score }
    })
    .sort((a, b) => (b.personalizedScore ?? 0) - (a.personalizedScore ?? 0))
}

export async function getSimilarPinsBySlug(slug: string) {
  // FIX: Also filter isHidden on the base pin lookup
  const base = await prisma.pin.findFirst({
    where: { slug, isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
  })
  if (!base) return []

  const all = await prisma.pin.findMany({
    where: { isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
  })
  return all
    .filter((pin) => pin.slug !== slug)
    .map((pin) => ({ ...mapPin(pin), similarity: similarityScore(base.tags, pin.tags) }))
    .filter((pin) => pin.similarity > 0)
    .sort((a, b) => b.similarity - a.similarity || (b.saveCount ?? 0) - (a.saveCount ?? 0))
    .slice(0, 8)
}

export async function searchPins(query?: string, tag?: string) {
  const all = await prisma.pin.findMany({
    where: { isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
    orderBy: { createdAt: "desc" },
  })
  const q = (query ?? "").trim().toLowerCase()
  const t = (tag ?? "").trim().toLowerCase()
  return all
    .filter((pin) => {
      const hay = [pin.title, pin.description, pin.tags].join(" ").toLowerCase()
      return (q ? hay.includes(q) : true) && (t ? pin.tags.toLowerCase().includes(t) : true)
    })
    .map(mapPin)
}

export async function getTrendingTags() {
  const pins = await prisma.pin.findMany({ where: { isHidden: false }, select: { tags: true } })
  const counts = new Map<string, number>()
  for (const pin of pins)
    for (const tag of normalizeTags(pin.tags)) counts.set(tag, (counts.get(tag) ?? 0) + 1)
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12)
    .map(([tag, count]) => ({ tag, count }))
}

export async function getRecommendedPins() {
  const pins = await prisma.pin.findMany({
    where: { isHidden: false },
    include: { author: true, _count: { select: { saves: true, reports: true } } },
    orderBy: [{ createdAt: "desc" }],
  })
  return pins
    .map(mapPin)
    .sort((a, b) => (b.saveCount * 10 + b.tags.length) - (a.saveCount * 10 + a.tags.length))
    .slice(0, 8)
}

export async function getAnalyticsSummary() {
  const events = await prisma.analyticsEvent.groupBy({ by: ["eventName"], _count: { eventName: true } })
  return events.map((item) => ({ eventName: item.eventName, count: item._count.eventName }))
}

export async function getAdminOverview() {
  const [userCount, pinCount, hiddenPinCount, reportCount, openReportCount, auditCount] = await Promise.all([
    prisma.user.count(),
    prisma.pin.count(),
    prisma.pin.count({ where: { isHidden: true } }),
    prisma.report.count(),
    prisma.report.count({ where: { status: "open" } }),
    prisma.auditLog.count(),
  ])
  return { userCount, pinCount, hiddenPinCount, reportCount, openReportCount, auditCount }
}

// Exported mapper for use in pages that do their own Prisma queries
export function mapPinForFeed(pin: any) {
  return {
    id: pin.id,
    title: pin.title,
    slug: pin.slug,
    description: pin.description,
    imageUrl: pin.imageUrl,
    width: pin.width,
    height: pin.height,
    tags: normalizeTags(pin.tags),
    rawTags: pin.tags,
    isHidden: pin.isHidden ?? false,
    saveCount: pin._count?.saves ?? 0,
    reportCount: pin._count?.reports ?? 0,
    createdAt: pin.createdAt,
    author: {
      id: pin.author.id,
      username: pin.author.username,
      name: pin.author.name ?? pin.author.username,
      image: pin.author.image ?? null,
    },
  }
}

describe("search ts_query builder", () => {
  // Mirrors the logic in lib/search.ts
  function buildTsQuery(query: string) {
    return query.split(/\s+/).filter(Boolean).map((w) => `${w}:*`).join(" & ")
  }

  it("builds prefix query for single word", () => {
    expect(buildTsQuery("chocolate")).toBe("chocolate:*")
  })

  it("builds AND query for multiple words", () => {
    expect(buildTsQuery("chocolate cake")).toBe("chocolate:* & cake:*")
  })

  it("handles extra whitespace", () => {
    expect(buildTsQuery("  dark  mode  ")).toBe("dark:* & mode:*")
  })

  it("returns empty string for empty query", () => {
    expect(buildTsQuery("")).toBe("")
  })
})

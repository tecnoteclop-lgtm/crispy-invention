import { rateLimit } from "@/lib/rate-limit"

describe("rateLimit", () => {
  it("allows requests within limit", () => {
    const key = `test-${Math.random()}`
    const result = rateLimit(key, 5, 60_000)
    expect(result.allowed).toBe(true)
    expect(result.remaining).toBe(4)
  })

  it("blocks requests over limit", () => {
    const key = `test-block-${Math.random()}`
    for (let i = 0; i < 3; i++) rateLimit(key, 3, 60_000)
    const result = rateLimit(key, 3, 60_000)
    expect(result.allowed).toBe(false)
    expect(result.remaining).toBe(0)
  })

  it("different keys are independent", () => {
    const key1 = `test-key1-${Math.random()}`
    const key2 = `test-key2-${Math.random()}`
    for (let i = 0; i < 3; i++) rateLimit(key1, 3, 60_000)
    const result = rateLimit(key2, 3, 60_000)
    expect(result.allowed).toBe(true)
  })
})

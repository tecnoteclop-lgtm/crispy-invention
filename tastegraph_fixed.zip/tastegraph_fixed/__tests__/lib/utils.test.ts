import { normalizeTags, cn } from "@/lib/utils"

describe("normalizeTags", () => {
  it("splits comma-separated tags", () => {
    expect(normalizeTags("food,drink,travel")).toEqual(["food", "drink", "travel"])
  })

  it("trims whitespace", () => {
    expect(normalizeTags("  food , drink , travel  ")).toEqual(["food", "drink", "travel"])
  })

  it("lowercases all tags", () => {
    expect(normalizeTags("FOOD,Drink")).toEqual(["food", "drink"])
  })

  it("filters empty strings", () => {
    expect(normalizeTags("food,,travel")).toEqual(["food", "travel"])
  })

  it("handles empty input", () => {
    expect(normalizeTags("")).toEqual([])
  })
})

describe("cn", () => {
  it("joins class names", () => {
    expect(cn("a", "b", "c")).toBe("a b c")
  })

  it("filters falsy values", () => {
    expect(cn("a", false, null, undefined, "b")).toBe("a b")
  })
})

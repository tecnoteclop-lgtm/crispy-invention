import { z } from "zod"

// Extract the same schema used in the register route and test it independently
const schema = z.object({
  name:     z.string().min(2),
  username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/),
  email:    z.string().email(),
  password: z.string().min(8),
})

describe("register schema validation", () => {
  const valid = { name: "Alice", username: "alice_99", email: "alice@example.com", password: "securepass" }

  it("accepts valid input", () => {
    expect(schema.safeParse(valid).success).toBe(true)
  })

  it("rejects short name", () => {
    expect(schema.safeParse({ ...valid, name: "A" }).success).toBe(false)
  })

  it("rejects short username", () => {
    expect(schema.safeParse({ ...valid, username: "ab" }).success).toBe(false)
  })

  it("rejects username with special chars", () => {
    expect(schema.safeParse({ ...valid, username: "alice!" }).success).toBe(false)
  })

  it("rejects invalid email", () => {
    expect(schema.safeParse({ ...valid, email: "not-an-email" }).success).toBe(false)
  })

  it("rejects short password", () => {
    expect(schema.safeParse({ ...valid, password: "short" }).success).toBe(false)
  })
})

import { MetadataRoute } from "next"
import { prisma } from "@/lib/prisma"

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.APP_BASE_URL || "http://localhost:3000"
  const pins = await prisma.pin.findMany({ select: { slug: true, createdAt: true } })
  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${base}/`, lastModified: new Date() },
    { url: `${base}/explore`, lastModified: new Date() },
    { url: `${base}/search`, lastModified: new Date() },
    { url: `${base}/trending`, lastModified: new Date() },
    { url: `${base}/privacy`, lastModified: new Date() },
    { url: `${base}/terms`, lastModified: new Date() },
  ]
  const pinRoutes: MetadataRoute.Sitemap = pins.map((pin) => ({
    url: `${base}/pin/${pin.slug}`,
    lastModified: pin.createdAt,
  }))
  return [...staticRoutes, ...pinRoutes]
}

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { TagChip } from "@/components/tag-chip"
import { getRecommendedPins, getTrendingTags } from "@/lib/db-queries"
import { MasonryFeed } from "@/components/masonry-feed"
export default async function TrendingPage() {
  const tags = await getTrendingTags()
  const recommended = await getRecommendedPins()
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading eyebrow="Trending" title="What is surfacing right now" description="A lightweight editorial and algorithmic layer before full recommendation infrastructure." />
          <div className="flex flex-wrap gap-2">{tags.map((item) => <TagChip key={item.tag} tag={item.tag} count={item.count} />)}</div>
          <section className="mt-10">
            <SectionHeading title="Recommended now" />
            <MasonryFeed items={recommended} />
          </section>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { TasteProfileCard } from "@/components/taste-profile-card"
import { RecommendationCard } from "@/components/recommendation-card"
import { authOptions } from "@/lib/auth"
import { getTasteProfile } from "@/lib/db-queries"

export default async function TasteProfilePage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) redirect("/auth/sign-in?callbackUrl=/taste-profile")
  const profile = await getTasteProfile(session.user.id)
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
            <TasteProfileCard items={profile} />
            <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">Signal explanation</p>
              <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink">How your current taste profile is built</h1>
              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <RecommendationCard item={{ title: "Saved-pin tags", description: "Every saved pin contributes weighted tags to your current profile." }} />
                <RecommendationCard item={{ title: "Overlap scoring", description: "Pins matching those tags rank higher in your personal feed." }} />
                <RecommendationCard item={{ title: "Popularity support", description: "Save counts help break ties while the product is young." }} />
                <RecommendationCard item={{ title: "Embeddings next", description: "Later you can replace this with vector similarity and learned ranking." }} />
              </div>
            </div>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

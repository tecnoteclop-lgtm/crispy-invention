import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

const schema = z.object({
  pinId: z.string().min(1),
  boardId: z.string().nullable().optional(),
})

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 })

    const existing = await prisma.save.findFirst({
      where: {
        userId: session.user.id,
        pinId: parsed.data.pinId,
        boardId: parsed.data.boardId ?? null,
      },
    })

    if (existing) {
      await prisma.save.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, saved: false })
    }

    await prisma.save.create({
      data: {
        userId: session.user.id,
        pinId: parsed.data.pinId,
        boardId: parsed.data.boardId ?? null,
      },
    })
    return NextResponse.json({ ok: true, saved: true })
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"
import { createNotification } from "@/lib/notifications"

const schema = z.object({ targetUserId: z.string().min(1) })

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown"
  const { allowed } = rateLimit(`follow:${ip}`, 60, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input." }, { status: 400 })

    const { targetUserId } = parsed.data

    if (targetUserId === session.user.id)
      return NextResponse.json({ error: "You cannot follow yourself." }, { status: 400 })

    const target = await prisma.user.findUnique({ where: { id: targetUserId } })
    if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 })

    const existing = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId: session.user.id, followingId: targetUserId } },
    })

    if (existing) {
      await prisma.follow.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, following: false })
    }

    await prisma.follow.create({
      data: { followerId: session.user.id, followingId: targetUserId },
    })

    // Notify the followed user
    await createNotification({
      type: "follow",
      userId: targetUserId,
      actorId: session.user.id,
    })

    return NextResponse.json({ ok: true, following: true })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

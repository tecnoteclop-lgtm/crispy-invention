import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// DELETE /api/comments/[id]  — author or admin only
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const comment = await prisma.comment.findUnique({ where: { id: params.id } })
  if (!comment) return NextResponse.json({ error: "Not found." }, { status: 404 })

  const isOwner = comment.authorId === session.user.id
  const isAdmin = session.user.role === "admin"
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Forbidden." }, { status: 403 })

  await prisma.comment.delete({ where: { id: params.id } })
  return NextResponse.json({ ok: true })
}

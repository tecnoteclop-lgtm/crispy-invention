import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"
import { createNotification } from "@/lib/notifications"

const postSchema = z.object({
  pinId: z.string().min(1),
  body: z.string().min(1).max(1000),
  parentId: z.string().optional(),
})

export async function GET(req: NextRequest) {
  const pinId = req.nextUrl.searchParams.get("pinId")
  if (!pinId) return NextResponse.json({ error: "pinId required" }, { status: 400 })

  const comments = await prisma.comment.findMany({
    where: { pinId, parentId: null },
    orderBy: { createdAt: "asc" },
    include: {
      author: { select: { id: true, username: true, name: true, image: true } },
      replies: {
        orderBy: { createdAt: "asc" },
        include: { author: { select: { id: true, username: true, name: true, image: true } } },
      },
    },
  })

  return NextResponse.json({ ok: true, comments })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown"
  const { allowed } = rateLimit(`comment:${ip}`, 30, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  try {
    const body = await req.json()
    const parsed = postSchema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input." }, { status: 400 })

    const { pinId, body: text, parentId } = parsed.data

    const pin = await prisma.pin.findUnique({ where: { id: pinId, isHidden: false } })
    if (!pin) return NextResponse.json({ error: "Pin not found." }, { status: 404 })

    let parentComment = null
    if (parentId) {
      parentComment = await prisma.comment.findUnique({ where: { id: parentId } })
      if (!parentComment || parentComment.pinId !== pinId)
        return NextResponse.json({ error: "Invalid parent comment." }, { status: 400 })
    }

    const comment = await prisma.comment.create({
      data: { body: text, pinId, authorId: session.user.id, parentId: parentId ?? null },
      include: { author: { select: { id: true, username: true, name: true, image: true } } },
    })

    // Notify pin author about new comment
    await createNotification({
      type: "comment",
      userId: pin.authorId,
      actorId: session.user.id,
      pinId: pin.id,
      commentId: comment.id,
      message: text.slice(0, 60),
    })

    // Notify parent comment author about reply
    if (parentComment && parentComment.authorId !== pin.authorId) {
      await createNotification({
        type: "reply",
        userId: parentComment.authorId,
        actorId: session.user.id,
        pinId: pin.id,
        commentId: comment.id,
        message: text.slice(0, 60),
      })
    }

    return NextResponse.json({ ok: true, comment })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

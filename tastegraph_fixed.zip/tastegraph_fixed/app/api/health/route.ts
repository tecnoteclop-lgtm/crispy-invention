import { NextResponse } from "next/server"
export async function GET() {
  return NextResponse.json({ ok: true, service: "tastegraph-production", timestamp: new Date().toISOString() })
}

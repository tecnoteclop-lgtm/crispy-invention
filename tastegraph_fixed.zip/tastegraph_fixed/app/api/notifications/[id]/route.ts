import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// PATCH /api/notifications/[id] — mark single notification as read
export async function PATCH(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const notif = await prisma.notification.findUnique({ where: { id: params.id } })
  if (!notif || notif.userId !== session.user.id)
    return NextResponse.json({ error: "Not found." }, { status: 404 })

  await prisma.notification.update({ where: { id: params.id }, data: { read: true } })
  return NextResponse.json({ ok: true })
}

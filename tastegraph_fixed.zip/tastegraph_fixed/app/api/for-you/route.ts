import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import { getForYouPins } from "@/lib/db-queries"
export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const items = await getForYouPins(session.user.id)
  return NextResponse.json({ strategy: "tag_overlap + popularity + freshness", items })
}

import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"

const schema = z.object({
  eventName: z.string().min(2),
  page: z.string().optional(),
  meta: z.record(z.any()).optional(),
})

export async function POST(req: Request) {
  const { allowed } = rateLimit("analytics", 100, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  const session = await getServerSession(authOptions)
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input." }, { status: 400 })

    const event = await prisma.analyticsEvent.create({
      data: {
        eventName: parsed.data.eventName,
        page: parsed.data.page,
        meta: parsed.data.meta ? JSON.stringify(parsed.data.meta) : undefined,
        userId: session?.user?.id,
      },
    })

    return NextResponse.json({ ok: true, item: event.id })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

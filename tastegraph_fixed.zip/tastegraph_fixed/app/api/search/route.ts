import { NextRequest, NextResponse } from "next/server"
import { searchPins, SortBy } from "@/lib/search"
import { rateLimit } from "@/lib/rate-limit"

// GET /api/search?q=&tag=&sort=relevance|recent|saves&cursor=
export async function GET(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown"
  const { allowed } = rateLimit(`search:${ip}`, 60, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  const { searchParams } = req.nextUrl
  const q      = searchParams.get("q")      ?? ""
  const tag    = searchParams.get("tag")    ?? ""
  const sortBy = (searchParams.get("sort")  ?? "relevance") as SortBy
  const cursor = searchParams.get("cursor") ?? undefined

  if (!q.trim() && !tag.trim()) {
    return NextResponse.json({ ok: true, items: [], hasMore: false, nextCursor: null, total: 0 })
  }

  try {
    const result = await searchPins({ q, tag, sortBy, cursor })
    return NextResponse.json({ ok: true, ...result })
  } catch {
    return NextResponse.json({ error: "Search failed." }, { status: 500 })
  }
}

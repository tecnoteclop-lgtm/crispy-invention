import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

const schema = z.object({
  isHidden: z.boolean(),
})

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 })

    const pin = await prisma.pin.update({
      where: { id: params.id },
      data: { isHidden: parsed.data.isHidden },
    })

    await prisma.auditLog.create({
      data: {
        action: parsed.data.isHidden ? "hide_pin" : "unhide_pin",
        targetType: "pin",
        targetId: pin.id,
        actorId: session.user.id,
      },
    })

    return NextResponse.json({ ok: true, item: pin })
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

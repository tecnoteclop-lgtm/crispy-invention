import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

const schema = z.object({
  status: z.enum(["open", "reviewing", "resolved", "dismissed"]),
})

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 })
    }

    const report = await prisma.report.update({
      where: { id: params.id },
      data: { status: parsed.data.status },
    })

    return NextResponse.json({ ok: true, item: report })
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

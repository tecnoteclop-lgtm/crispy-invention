import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"
import { createNotification } from "@/lib/notifications"

const schema = z.object({ pinId: z.string().min(1) })

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown"
  const { allowed } = rateLimit(`like:${ip}`, 60, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input." }, { status: 400 })

    const { pinId } = parsed.data

    const pin = await prisma.pin.findUnique({ where: { id: pinId, isHidden: false } })
    if (!pin) return NextResponse.json({ error: "Pin not found." }, { status: 404 })

    const existing = await prisma.like.findUnique({
      where: { pinId_userId: { pinId, userId: session.user.id } },
    })

    if (existing) {
      await prisma.like.delete({ where: { id: existing.id } })
      const count = await prisma.like.count({ where: { pinId } })
      return NextResponse.json({ ok: true, liked: false, count })
    }

    await prisma.like.create({ data: { pinId, userId: session.user.id } })
    const count = await prisma.like.count({ where: { pinId } })

    // Notify pin author
    await createNotification({
      type: "like",
      userId: pin.authorId,
      actorId: session.user.id,
      pinId: pin.id,
    })

    return NextResponse.json({ ok: true, liked: true, count })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

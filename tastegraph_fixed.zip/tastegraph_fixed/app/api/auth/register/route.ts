import { NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"

const schema = z.object({
  name: z.string().min(2),
  username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers and underscores"),
  email: z.string().email(),
  password: z.string().min(8),
})

export async function POST(req: NextRequest) {
  // Rate limit per IP address, not globally
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? req.headers.get("x-real-ip") ?? "unknown"
  const { allowed } = rateLimit(`register:${ip}`, 10, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input." }, { status: 400 })

    const { name, username, email, password } = parsed.data
    const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } })
    if (existing) return NextResponse.json({ error: "Email or username already exists." }, { status: 409 })

    const hashed = await bcrypt.hash(password, 12)
    const user = await prisma.user.create({ data: { name, username, email, password: hashed } })
    return NextResponse.json({ ok: true, userId: user.id })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

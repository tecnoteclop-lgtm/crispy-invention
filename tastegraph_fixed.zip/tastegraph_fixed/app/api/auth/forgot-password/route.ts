import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/prisma"
import crypto from "crypto"

const schema = z.object({
  email: z.string().email(),
})

// Token expiry: 1 hour
const EXPIRY_MS = 60 * 60 * 1000

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 })
    }

    const { email } = parsed.data

    // Always return success to prevent email enumeration attacks
    const user = await prisma.user.findUnique({ where: { email } })

    if (user) {
      const token = crypto.randomBytes(32).toString("hex")
      const expiresAt = new Date(Date.now() + EXPIRY_MS)

      // TODO: Store token in DB with expiry and send reset email via your email provider.
      // Example storage (add PasswordResetToken model to schema.prisma):
      //
      // await prisma.passwordResetToken.upsert({
      //   where: { userId: user.id },
      //   update: { token, expiresAt },
      //   create: { userId: user.id, token, expiresAt },
      // })
      //
      // Then send email:
      // await sendEmail({
      //   to: email,
      //   subject: "Reset your password",
      //   html: `<a href="${process.env.APP_BASE_URL}/auth/reset-password?token=${token}">Reset password</a>`,
      // })

      console.log(`[DEV] Password reset token for ${email}: ${token} (expires ${expiresAt.toISOString()})`)
    }

    // Always return 200 — never reveal whether the email exists
    return NextResponse.json({
      ok: true,
      message: "If that email is registered, a password reset link has been sent.",
    })
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

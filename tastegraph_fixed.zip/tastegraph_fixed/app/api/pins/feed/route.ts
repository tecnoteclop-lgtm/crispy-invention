import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { searchPins, SortBy } from "@/lib/search"
import { normalizeTags } from "@/lib/utils"

const PAGE_SIZE = 20

function mapPin(pin: any) {
  return {
    id: pin.id,
    title: pin.title,
    slug: pin.slug,
    description: pin.description,
    imageUrl: pin.imageUrl,
    width: pin.width,
    height: pin.height,
    tags: normalizeTags(pin.tags),
    saveCount: pin._count?.saves ?? 0,
    createdAt: pin.createdAt,
    author: {
      id: pin.author.id,
      username: pin.author.username,
      name: pin.author.name ?? pin.author.username,
      image: pin.author.image ?? null,
    },
  }
}

// GET /api/pins/feed?cursor=&q=&tag=&sort=
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const cursor = searchParams.get("cursor") ?? undefined
  const q      = searchParams.get("q")?.trim() ?? ""
  const tag    = searchParams.get("tag")?.trim() ?? ""
  const sortBy = (searchParams.get("sort") ?? "recent") as SortBy

  // If searching, delegate to full-text search
  if (q || tag) {
    try {
      const result = await searchPins({ q, tag, sortBy, cursor, take: PAGE_SIZE })
      return NextResponse.json({ ok: true, ...result })
    } catch {
      return NextResponse.json({ error: "Search failed." }, { status: 500 })
    }
  }

  // Plain browse (no query) — cursor-based pagination
  const where: any = { isHidden: false }
  if (cursor) where.createdAt = { lt: new Date(cursor) }

  const pins = await prisma.pin.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: PAGE_SIZE + 1,
    include: { author: true, _count: { select: { saves: true } } },
  })

  const hasMore    = pins.length > PAGE_SIZE
  const items      = pins.slice(0, PAGE_SIZE).map(mapPin)
  const nextCursor = hasMore ? (items[items.length - 1].createdAt as Date).toISOString() : null

  return NextResponse.json({ ok: true, items, hasMore, nextCursor })
}

import { revalidateTag } from "next/cache"
import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const pin = await prisma.pin.findUnique({ where: { id: params.id } })
  if (!pin) return NextResponse.json({ error: "Not found." }, { status: 404 })

  const isOwner = pin.authorId === session.user.id
  const isAdmin = session.user.role === "admin"
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Forbidden." }, { status: 403 })

  await prisma.pin.delete({ where: { id: params.id } })

  revalidateTag("pins")
  revalidateTag("tags")

  return NextResponse.json({ ok: true })
}

import { revalidateTag } from "next/cache"
import { getServerSession } from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { rateLimit } from "@/lib/rate-limit"

const schema = z.object({
  title:       z.string().min(3).max(120),
  description: z.string().min(10).max(1000),
  imageUrl:    z.string().url(),
  width:       z.number().int().positive(),
  height:      z.number().int().positive(),
  tags:        z.string().min(1).max(200),
  sourceUrl:   z.string().url().optional().or(z.literal("")),
})

function slugify(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-").replace(/-+/g, "-").slice(0, 80)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown"
  const { allowed } = rateLimit(`pin-create:${ip}`, 20, 60_000)
  if (!allowed) return NextResponse.json({ error: "Too many requests." }, { status: 429 })

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: "Invalid input.", details: parsed.error.flatten() }, { status: 400 })

    const { title, description, imageUrl, width, height, tags, sourceUrl } = parsed.data

    const base = slugify(title)
    let slug = base, attempt = 0
    while (await prisma.pin.findUnique({ where: { slug } })) { attempt++; slug = `${base}-${attempt}` }

    const pin = await prisma.pin.create({
      data: { title, description, imageUrl, width, height, tags, sourceUrl: sourceUrl || null, slug, authorId: session.user.id },
    })

    // Bust caches
    revalidateTag("pins")
    revalidateTag("tags")

    return NextResponse.json({ ok: true, pin: { id: pin.id, slug: pin.slug } })
  } catch {
    return NextResponse.json({ error: "Server error." }, { status: 500 })
  }
}

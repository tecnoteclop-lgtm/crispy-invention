import { NextResponse } from "next/server"
import { getSimilarPinsBySlug } from "@/lib/db-queries"
export async function GET(_req: Request, { params }: { params: { slug: string } }) {
  const items = await getSimilarPinsBySlug(params.slug)
  return NextResponse.json({ strategy: "tag_overlap", items })
}

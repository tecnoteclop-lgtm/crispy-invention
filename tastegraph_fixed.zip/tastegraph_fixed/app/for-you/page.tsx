import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { MasonryFeed } from "@/components/masonry-feed"
import { TasteProfileCard } from "@/components/taste-profile-card"
import { PageTrack } from "@/components/page-track"
import { authOptions } from "@/lib/auth"
import { getForYouPins, getTasteProfile } from "@/lib/db-queries"

export default async function ForYouPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) redirect("/auth/sign-in?callbackUrl=/for-you")
  const profile = await getTasteProfile(session.user.id)
  const pins = await getForYouPins(session.user.id)
  return (
    <div className="min-h-screen bg-surface">
      <PageTrack eventName="page_view" page="/for-you" />
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
            <TasteProfileCard items={profile} />
            <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">For You</p>
              <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink">Pins scored for your current taste profile</h1>
              <p className="mt-4 max-w-2xl leading-8 text-muted">This feed combines save-derived preference signals with light popularity support.</p>
            </div>
          </div>
          <section className="mt-12">
            <SectionHeading title="Your ranked feed" />
            <MasonryFeed items={pins} />
          </section>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <h1 className="text-4xl font-semibold tracking-tight text-ink">Privacy Policy</h1>
            <div className="mt-6 space-y-4 text-muted">
              <p>This starter privacy page explains that the product may collect account information, saved content, analytics events and reports.</p>
              <p>Before launch, replace this with a real policy tailored to your stack, vendors, retention periods and legal jurisdictions.</p>
              <p>Key sections to finalize: data collection, storage, third-party processors, international transfers, user rights and contact details.</p>
            </div>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

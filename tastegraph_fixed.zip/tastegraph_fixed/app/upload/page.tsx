import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { Metadata } from "next"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { PinUploadForm } from "@/components/pin-upload-form"
import { authOptions } from "@/lib/auth"

export const metadata: Metadata = { title: "Upload a Pin" }

export default async function UploadPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect("/auth/sign-in?callbackUrl=/upload")

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading
            eyebrow="Create"
            title="Upload a new pin"
            description="Share something that inspires you. Add tags so others can discover it."
          />
          <div className="mx-auto max-w-4xl">
            <PinUploadForm />
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

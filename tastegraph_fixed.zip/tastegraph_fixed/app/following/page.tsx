import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { Metadata } from "next"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { MasonryFeed } from "@/components/masonry-feed"
import { EmptyState } from "@/components/empty-state"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { mapPinForFeed } from "@/lib/db-queries"

export const metadata: Metadata = { title: "Following" }

export default async function FollowingPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) redirect("/auth/sign-in?callbackUrl=/following")

  // Get IDs of people the current user follows
  const follows = await prisma.follow.findMany({
    where: { followerId: session.user.id },
    select: { followingId: true },
  })
  const followingIds = follows.map((f) => f.followingId)

  const pins = followingIds.length
    ? await prisma.pin.findMany({
        where: { authorId: { in: followingIds }, isHidden: false },
        orderBy: { createdAt: "desc" },
        include: { author: true, _count: { select: { saves: true, reports: true } } },
      })
    : []

  const feed = pins.map(mapPinForFeed)

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading
            eyebrow="Following"
            title="Pins from people you follow"
            description="Stay up to date with the creators you love."
          />
          {feed.length ? (
            <MasonryFeed items={feed} />
          ) : (
            <EmptyState
              title="Nothing here yet"
              description={followingIds.length === 0
                ? "You're not following anyone yet. Discover creators and follow them."
                : "The people you follow haven't posted anything yet."}
              actionLabel="Explore creators"
              actionHref="/explore"
            />
          )}
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

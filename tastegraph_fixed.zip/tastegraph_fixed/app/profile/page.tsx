import Image from "next/image"
import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { BoardCard } from "@/components/board-card"
import { ProfileEditForm } from "@/components/profile-edit-form"
import { EmptyState } from "@/components/empty-state"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { getUserBoards } from "@/lib/db-queries"

export default async function ProfilePage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) redirect("/auth/sign-in?callbackUrl=/profile")
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  const boards = await getUserBoards(session.user.id)

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[1fr_420px]">
            <div>
              <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
                <div className="flex items-center gap-4">
                  <Image
                    src={user?.image ?? "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80"}
                    alt="profile"
                    width={84}
                    height={84}
                    className="rounded-full object-cover"
                  />
                  <div>
                    <h1 className="text-3xl font-semibold tracking-tight text-ink">{user?.name ?? user?.username}</h1>
                    <p className="mt-1 text-muted">@{user?.username} · {user?.role}</p>
                  </div>
                </div>
                <p className="mt-6 max-w-2xl leading-8 text-muted">{user?.bio ?? "Creator profile bio goes here."}</p>
              </div>

              <section className="mt-12">
                <h2 className="mb-6 text-2xl font-semibold tracking-tight text-ink">My boards</h2>
                {boards.length ? (
                  <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                    {boards.map((board) => <BoardCard key={board.id} board={board} />)}
                  </div>
                ) : (
                  <EmptyState
                    title="No boards yet"
                    description="Create your first board and start organizing your saved inspiration."
                    actionLabel="Explore pins"
                    actionHref="/explore"
                  />
                )}
              </section>
            </div>

            <ProfileEditForm
              initialName={user?.name ?? ""}
              initialBio={user?.bio ?? ""}
              initialImage={user?.image ?? ""}
            />
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

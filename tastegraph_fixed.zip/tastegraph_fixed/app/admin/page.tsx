import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { AdminReportActions } from "@/components/admin-report-actions"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { getAdminOverview } from "@/lib/db-queries"

export default async function AdminPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect("/auth/sign-in?callbackUrl=/admin")
  if (session.user.role !== "admin") redirect("/")

  const overview = await getAdminOverview()
  const reports = await prisma.report.findMany({
    orderBy: { createdAt: "desc" },
    include: { pin: true, reporter: true },
  })
  const auditLogs = await prisma.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
    include: { actor: true },
  })

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <h1 className="text-4xl font-semibold tracking-tight text-ink">Admin panel</h1>

          <div className="mt-8 grid gap-4 md:grid-cols-3 xl:grid-cols-6">
            <Stat label="Users" value={overview.userCount} />
            <Stat label="Pins" value={overview.pinCount} />
            <Stat label="Hidden pins" value={overview.hiddenPinCount} />
            <Stat label="Reports" value={overview.reportCount} />
            <Stat label="Open reports" value={overview.openReportCount} />
            <Stat label="Audit logs" value={overview.auditCount} />
          </div>

          <section className="mt-10">
            <h2 className="mb-4 text-2xl font-semibold text-ink">Reports queue</h2>
            <div className="grid gap-4">
              {reports.map((report) => (
                <div key={report.id} className="rounded-[28px] border border-line bg-card p-6 shadow-soft">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-lg font-semibold text-ink">{report.pin.title}</p>
                      <p className="mt-1 text-sm text-muted">
                        @{report.reporter.username} · {report.reason} · {report.status}
                      </p>
                    </div>
                    <span className="rounded-full bg-surface px-3 py-1 text-xs font-medium text-muted">
                      {report.pin.isHidden ? "pin hidden" : "pin visible"}
                    </span>
                  </div>
                  {report.notes ? <p className="mt-4 text-sm text-slate-700">{report.notes}</p> : null}
                  <AdminReportActions
                    reportId={report.id}
                    currentStatus={report.status}
                    pinId={report.pin.id}
                    pinHidden={report.pin.isHidden}
                  />
                </div>
              ))}
            </div>
          </section>

          <section className="mt-10">
            <h2 className="mb-4 text-2xl font-semibold text-ink">Recent audit log</h2>
            <div className="grid gap-4">
              {auditLogs.map((log) => (
                <div key={log.id} className="rounded-[24px] border border-line bg-card p-5 shadow-soft">
                  <p className="font-medium text-ink">{log.action}</p>
                  <p className="mt-1 text-sm text-muted">
                    {log.targetType} · {log.targetId} · by @{log.actor.username}
                  </p>
                </div>
              ))}
            </div>
          </section>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-[24px] border border-line bg-card p-5 shadow-soft">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 text-3xl font-semibold text-ink">{value}</p>
    </div>
  )
}

import { Metadata } from "next"
import { Suspense } from "react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { SearchForm } from "@/components/search-form"
import { InfiniteMasonryFeed } from "@/components/infinite-masonry-feed"
import { searchPins, SortBy } from "@/lib/search"

export const metadata: Metadata = { title: "Search" }

interface Props {
  searchParams: { q?: string; tag?: string; sort?: string }
}

export default async function SearchPage({ searchParams }: Props) {
  const q      = (searchParams.q    ?? "").trim()
  const tag    = (searchParams.tag  ?? "").trim()
  const sortBy = (searchParams.sort ?? "relevance") as SortBy

  const hasQuery = q || tag

  // SSR: first page via full-text search
  const { items: firstPage, hasMore, nextCursor } = hasQuery
    ? await searchPins({ q, tag, sortBy, take: 20 })
    : { items: [], hasMore: false, nextCursor: null }

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading
            eyebrow="Search"
            title="Find your visual direction"
            description="Full-text search across titles, descriptions and tags. Results update as you type."
          />

          {/* SearchForm reads searchParams — needs Suspense for useSearchParams */}
          <Suspense>
            <SearchForm />
          </Suspense>

          {/* Results summary */}
          {hasQuery && (
            <div className="mt-5 rounded-[24px] border border-line bg-card px-5 py-4 shadow-soft">
              <div className="flex items-center justify-between gap-4">
                <p className="text-sm text-muted">
                  {firstPage.length === 0
                    ? "No pins found"
                    : <><span className="font-semibold text-ink">{firstPage.length}{hasMore ? "+" : ""}</span> pins found</>
                  }
                  {q   ? <> for <span className="font-medium text-ink">"{q}"</span></> : null}
                  {tag ? <> tagged <span className="ml-1 rounded-full bg-surface px-2 py-0.5 text-xs font-medium text-brand">#{tag}</span></> : null}
                </p>
                {sortBy !== "relevance" && (
                  <span className="text-xs text-muted/70">
                    Sorted by: {sortBy === "saves" ? "most saved" : "most recent"}
                  </span>
                )}
              </div>
            </div>
          )}

          <div className="mt-8">
            {!hasQuery ? (
              // Empty state — suggest popular tags
              <div className="rounded-[32px] border border-line bg-card p-10 text-center shadow-soft">
                <p className="text-2xl">🔍</p>
                <p className="mt-3 text-base font-medium text-ink">Start typing to search</p>
                <p className="mt-1 text-sm text-muted">Try searching for a mood, style, or ingredient</p>
                <div className="mt-6 flex flex-wrap justify-center gap-2">
                  {["minimal", "typography", "food", "architecture", "colour", "nature"].map((s) => (
                    <a
                      key={s}
                      href={`/search?q=${s}`}
                      className="rounded-full border border-line px-4 py-2 text-sm font-medium text-muted hover:bg-surface"
                    >
                      {s}
                    </a>
                  ))}
                </div>
              </div>
            ) : firstPage.length === 0 ? (
              <div className="rounded-[32px] border border-line bg-card p-10 text-center shadow-soft">
                <p className="text-2xl">😶</p>
                <p className="mt-3 text-base font-medium text-ink">No results found</p>
                <p className="mt-1 text-sm text-muted">Try a different keyword or remove the tag filter</p>
              </div>
            ) : (
              <InfiniteMasonryFeed
                initialItems={firstPage}
                initialHasMore={hasMore}
                initialCursor={nextCursor}
                query={q}
                tag={tag}
              />
            )}
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

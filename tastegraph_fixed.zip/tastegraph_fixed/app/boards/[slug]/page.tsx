import { getServerSession } from "next-auth"
import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { MasonryFeed } from "@/components/masonry-feed"
import { BoardManageForm } from "@/components/board-manage-form"
import { EmptyState } from "@/components/empty-state"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export default async function BoardDetailPage({ params }: { params: { slug: string } }) {
  const session = await getServerSession(authOptions)
  const board = await prisma.board.findUnique({
    where: { slug: params.slug },
    include: {
      saves: { include: { pin: { include: { author: true, _count: { select: { saves: true } } } } } },
      _count: { select: { saves: true } },
    },
  })
  if (!board) return notFound()

  const pins = board.saves.map((save) => ({
    id: save.pin.id,
    title: save.pin.title,
    slug: save.pin.slug,
    description: save.pin.description,
    imageUrl: save.pin.imageUrl,
    width: save.pin.width,
    height: save.pin.height,
    tags: save.pin.tags.split(",").map((tag) => tag.trim()).filter(Boolean),
    saveCount: save.pin._count.saves,
    author: {
      username: save.pin.author.username,
      name: save.pin.author.name ?? save.pin.author.username,
      image: save.pin.author.image ?? "",
    },
  }))

  const isOwner = session?.user?.id === board.ownerId

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[1fr_420px]">
            <div>
              <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">Board</p>
                <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink">{board.name}</h1>
                <p className="mt-3 max-w-2xl text-muted">{board.description}</p>
                <p className="mt-3 text-sm text-muted">{board._count.saves} saved pins</p>
              </div>

              <div className="mt-8">
                {pins.length ? (
                  <MasonryFeed items={pins} />
                ) : (
                  <EmptyState
                    title="This board is empty"
                    description="Start saving pins into this board to build a visual collection."
                    actionLabel="Explore pins"
                    actionHref="/explore"
                  />
                )}
              </div>
            </div>

            {isOwner ? (
              <BoardManageForm
                boardId={board.id}
                initialName={board.name}
                initialDescription={board.description ?? ""}
              />
            ) : null}
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

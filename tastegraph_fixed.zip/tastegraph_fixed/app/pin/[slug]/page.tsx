import Link from "next/link"
import Image from "next/image"
import { getServerSession } from "next-auth"
import { notFound } from "next/navigation"
import { Metadata } from "next"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { MasonryFeed } from "@/components/masonry-feed"
import { SaveToggleForm } from "@/components/save-toggle-form"
import { PinDeleteForm } from "@/components/pin-delete-form"
import { LikeButton } from "@/components/like-button"
import { CommentSection } from "@/components/comment-section"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { getPinBySlug, getSimilarPinsBySlug } from "@/lib/db-queries"

interface Props { params: { slug: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const pin = await getPinBySlug(params.slug)
  if (!pin) return { title: "Pin not found" }
  return { title: pin.title, description: pin.description }
}

export default async function PinDetailPage({ params }: Props) {
  const pin = await getPinBySlug(params.slug)
  if (!pin) return notFound()

  const similar = await getSimilarPinsBySlug(params.slug)
  const session = await getServerSession(authOptions)

  // Save state
  let saved = false
  if (session?.user?.id) {
    const existing = await prisma.save.findFirst({
      where: { userId: session.user.id, pinId: pin.id, boardId: null },
    })
    saved = Boolean(existing)
  }

  // Like state + count
  const likeCount = await prisma.like.count({ where: { pinId: pin.id } })
  let liked = false
  if (session?.user?.id) {
    const existingLike = await prisma.like.findUnique({
      where: { pinId_userId: { pinId: pin.id, userId: session.user.id } },
    })
    liked = Boolean(existingLike)
  }

  const isOwner = session?.user?.id === pin.author.id

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="grid gap-8 rounded-[32px] border border-line bg-card p-5 shadow-soft md:grid-cols-[0.9fr_1.1fr] md:p-8">
            {/* Image */}
            <div className="overflow-hidden rounded-[28px]">
              <Image
                src={pin.imageUrl}
                alt={pin.title}
                width={pin.width}
                height={pin.height}
                className="h-auto w-full object-cover"
              />
            </div>

            {/* Details */}
            <div className="py-2">
              <div className="flex flex-wrap gap-2">
                {pin.tags.map((tag) => (
                  <Link key={tag} href={`/search?tag=${tag}`} className="rounded-full bg-surface px-3 py-1 text-xs font-medium text-muted hover:bg-brand hover:text-white transition">
                    #{tag}
                  </Link>
                ))}
              </div>

              <h1 className="mt-5 text-4xl font-semibold tracking-tight text-ink">{pin.title}</h1>
              <p className="mt-4 max-w-2xl leading-8 text-muted">{pin.description}</p>

              {/* Stats row */}
              <div className="mt-6 flex flex-wrap items-center gap-3">
                {session?.user ? (
                  <LikeButton pinId={pin.id} initialLiked={liked} initialCount={likeCount} />
                ) : (
                  <span className="flex items-center gap-1.5 rounded-full border border-line bg-card px-4 py-2 text-sm text-muted">
                    ❤️ {likeCount}
                  </span>
                )}
                <span className="text-sm text-muted/70">{pin.saveCount} saves</span>
              </div>

              {/* Author */}
              <div className="mt-8 rounded-[28px] bg-surface p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">Creator</p>
                <div className="mt-3 flex items-center gap-4">
                  <Link href={`/user/${pin.author.username}`}>
                    <Image
                      src={pin.author.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(pin.author.name)}`}
                      alt={pin.author.name}
                      width={60}
                      height={60}
                      className="rounded-full object-cover"
                    />
                  </Link>
                  <div>
                    <Link href={`/user/${pin.author.username}`} className="text-lg font-semibold text-ink hover:underline">
                      {pin.author.name}
                    </Link>
                    <p className="text-sm text-muted">@{pin.author.username}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-6 flex flex-col gap-3">
                {session?.user ? <SaveToggleForm pinId={pin.id} initialSaved={saved} /> : null}
                {isOwner ? <PinDeleteForm pinId={pin.id} /> : null}
              </div>

              {/* Source link */}
              {pin.sourceUrl ? (
                <a
                  href={pin.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-block text-xs text-muted/70 underline hover:text-brand"
                >
                  View source ↗
                </a>
              ) : null}
            </div>
          </div>

          {/* Comments */}
          <div className="mt-10 rounded-[32px] border border-line bg-card p-6 shadow-soft md:p-10">
            <CommentSection
              pinId={pin.id}
              currentUserId={session?.user?.id}
              currentUserRole={session?.user?.role}
            />
          </div>

          {/* Similar pins */}
          {similar.length > 0 && (
            <section className="mt-12">
              <SectionHeading title="Similar pins" description="Based on tag overlap." />
              <MasonryFeed items={similar} />
            </section>
          )}
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

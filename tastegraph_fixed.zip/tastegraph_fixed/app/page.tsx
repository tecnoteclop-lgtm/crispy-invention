import Link from "next/link"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { CategoryPills } from "@/components/category-pills"
import { MasonryFeed } from "@/components/masonry-feed"
import { RecommendationCard } from "@/components/recommendation-card"
import { PageTrack } from "@/components/page-track"
import { getCachedRecommendedPins } from "@/lib/cache"
import { getAnalyticsSummary } from "@/lib/db-queries"

export default async function HomePage() {
  const recommended = await getCachedRecommendedPins()
  const analytics   = await getAnalyticsSummary()

  return (
    <div className="min-h-screen bg-surface">
      <PageTrack eventName="page_view" page="/" />
      <SiteHeader />
      <main className="py-14">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">TasteGraph</p>
              <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink md:text-5xl">
                Discover, save, and share visual inspiration.
              </h1>
              <p className="mt-4 max-w-2xl leading-8 text-muted">
                Your personalised pin feed gets smarter the more you save. Follow creators, like and comment on pins, and let the algorithm surface what matters to you.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/explore"  className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white">Explore pins</Link>
                <Link href="/for-you"  className="rounded-full border border-line px-5 py-3 text-sm font-medium text-ink">For You</Link>
                <Link href="/upload"   className="rounded-full border border-line px-5 py-3 text-sm font-medium text-ink">Upload a pin</Link>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <RecommendationCard item={{ title: "Infinite scroll",  description: "Explore and Search pages load new pins automatically as you scroll." }} />
              <RecommendationCard item={{ title: "Notifications",    description: "Get notified when someone likes, comments, or follows you." }} />
              <RecommendationCard item={{ title: "Comments & Likes", description: "Engage with pins through threaded comments and likes." }} />
              <RecommendationCard item={{ title: "Following feed",   description: "See pins only from creators you follow in the Following tab." }} />
            </div>
          </div>

          <section className="mt-14">
            <SectionHeading eyebrow="Browse" title="Popular directions" />
            <CategoryPills />
          </section>

          <section className="mt-14">
            <div className="flex items-end justify-between">
              <SectionHeading eyebrow="Recommended now" title="Top pins" />
              <Link href="/explore" className="mb-2 text-sm font-medium text-brand hover:underline">View all →</Link>
            </div>
            <MasonryFeed items={recommended} />
          </section>

          {analytics.length > 0 && (
            <section className="mt-14">
              <SectionHeading eyebrow="Analytics snapshot" title="Current event counts" />
              <div className="grid gap-4 md:grid-cols-3">
                {analytics.map((item) => (
                  <div key={item.eventName} className="rounded-[28px] border border-line bg-card p-6 shadow-soft">
                    <p className="text-sm text-muted">{item.eventName}</p>
                    <p className="mt-2 text-3xl font-semibold text-ink">{item.count}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

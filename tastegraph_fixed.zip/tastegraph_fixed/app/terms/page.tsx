import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <h1 className="text-4xl font-semibold tracking-tight text-ink">Terms of Service</h1>
            <div className="mt-6 space-y-4 text-muted">
              <p>This starter terms page should eventually define account rules, acceptable use, IP handling, takedown process, disclaimers and termination rights.</p>
              <p>Before launch, have counsel review the final text for your geography and business model.</p>
            </div>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"

export default function ReportPage() {
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <h1 className="text-4xl font-semibold tracking-tight text-ink">Report a problem</h1>
            <div className="mt-6 space-y-4 text-muted">
              <p>Use in-product reporting for content. This page is the starter for broader issues like abuse, account impersonation or copyright requests.</p>
              <p>Before launch, connect this page to a support inbox or ticketing flow.</p>
            </div>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

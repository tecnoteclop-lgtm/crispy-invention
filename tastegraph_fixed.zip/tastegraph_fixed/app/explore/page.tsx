import { Metadata } from "next"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { CategoryPills } from "@/components/category-pills"
import { InfiniteMasonryFeed } from "@/components/infinite-masonry-feed"
import { prisma } from "@/lib/prisma"
import { normalizeTags } from "@/lib/utils"

export const metadata: Metadata = { title: "Explore" }

const PAGE_SIZE = 20

function mapPin(pin: any) {
  return {
    id: pin.id,
    title: pin.title,
    slug: pin.slug,
    description: pin.description,
    imageUrl: pin.imageUrl,
    width: pin.width,
    height: pin.height,
    tags: normalizeTags(pin.tags),
    saveCount: pin._count?.saves ?? 0,
    createdAt: pin.createdAt,
    author: {
      id: pin.author.id,
      username: pin.author.username,
      name: pin.author.name ?? pin.author.username,
      image: pin.author.image ?? null,
    },
  }
}

export default async function ExplorePage() {
  // SSR: first page
  const raw = await prisma.pin.findMany({
    where: { isHidden: false },
    orderBy: { createdAt: "desc" },
    take: PAGE_SIZE + 1,
    include: { author: true, _count: { select: { saves: true } } },
  })

  const hasMore    = raw.length > PAGE_SIZE
  const firstPage  = raw.slice(0, PAGE_SIZE).map(mapPin)
  const nextCursor = hasMore ? (firstPage[firstPage.length - 1]?.createdAt as Date).toISOString() : null

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading
            eyebrow="Explore"
            title="A premium inspiration feed"
            description="Scroll endlessly — new pins load automatically as you go."
          />
          <CategoryPills />
          <div className="mt-8">
            <InfiniteMasonryFeed
              initialItems={firstPage}
              initialHasMore={hasMore}
              initialCursor={nextCursor}
            />
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"

export default function VerifyEmailPage() {
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="mx-auto max-w-xl rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <h1 className="text-3xl font-semibold tracking-tight text-ink">Verify email</h1>
            <p className="mt-3 text-muted">This page is the placeholder for a token-based email verification flow. Wire it to a real email provider before launch.</p>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

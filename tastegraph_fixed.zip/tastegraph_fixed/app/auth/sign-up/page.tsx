import { Metadata } from "next"
import { Suspense } from "react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SignUpForm } from "@/components/sign-up-form"
import { OAuthButtons } from "@/components/oauth-buttons"

export const metadata: Metadata = { title: "Create account" }

export default function SignUpPage() {
  return (
    <div className="min-h-screen bg-canvas">
      <SiteHeader />
      <main className="py-16">
        <Container>
          <div className="mx-auto max-w-md">
            <h1 className="mb-8 text-center text-3xl font-semibold tracking-tight text-ink">Create your account</h1>

            <Suspense>
              <OAuthButtons callbackUrl="/" />
            </Suspense>

            <div className="my-6 flex items-center gap-3">
              <div className="h-px flex-1 bg-line" />
              <span className="text-xs text-muted">or sign up with email</span>
              <div className="h-px flex-1 bg-line" />
            </div>

            <SignUpForm />
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

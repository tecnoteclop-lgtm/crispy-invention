import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"

export default function ForgotPasswordPage() {
  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <div className="mx-auto max-w-xl rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <h1 className="text-3xl font-semibold tracking-tight text-ink">Forgot password</h1>
            <p className="mt-3 text-muted">This is a product stub. In production, connect this form to a real email delivery provider and time-limited reset tokens.</p>
            <form className="mt-6 grid gap-4">
              <input type="email" placeholder="you@example.com" className="rounded-2xl border border-line px-4 py-3 outline-none" />
              <button className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white">Send reset link</button>
            </form>
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

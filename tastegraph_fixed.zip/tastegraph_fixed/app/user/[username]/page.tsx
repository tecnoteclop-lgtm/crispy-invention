import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { getServerSession } from "next-auth"
import { Metadata } from "next"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { MasonryFeed } from "@/components/masonry-feed"
import { FollowButton } from "@/components/follow-button"
import { EmptyState } from "@/components/empty-state"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { getPins } from "@/lib/db-queries"

interface Props { params: { username: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const user = await prisma.user.findUnique({ where: { username: params.username } })
  if (!user) return { title: "User not found" }
  return { title: `${user.name ?? user.username} (@${user.username})` }
}

export default async function UserProfilePage({ params }: Props) {
  const session = await getServerSession(authOptions)

  const user = await prisma.user.findUnique({
    where: { username: params.username },
    include: {
      _count: { select: { followers: true, following: true, pins: true } },
    },
  })
  if (!user) return notFound()

  const isOwnProfile = session?.user?.id === user.id
  const isSelf = isOwnProfile

  // Check if current user follows this profile
  let isFollowing = false
  if (session?.user?.id && !isSelf) {
    const follow = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId: session.user.id, followingId: user.id } },
    })
    isFollowing = Boolean(follow)
  }

  // Get this user's pins
  const allPins = await getPins()
  const userPins = allPins.filter((p) => p.author.id === user.id)

  // Followers list (last 12)
  const followerUsers = await prisma.follow.findMany({
    where: { followingId: user.id },
    orderBy: { createdAt: "desc" },
    take: 12,
    include: { follower: { select: { id: true, username: true, name: true, image: true } } },
  })

  // Following list (last 12)
  const followingUsers = await prisma.follow.findMany({
    where: { followerId: user.id },
    orderBy: { createdAt: "desc" },
    take: 12,
    include: { following: { select: { id: true, username: true, name: true, image: true } } },
  })

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          {/* Profile card */}
          <div className="rounded-[32px] border border-line bg-card p-8 shadow-soft">
            <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
              <div className="flex items-center gap-5">
                <Image
                  src={user.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name ?? user.username)}&size=200`}
                  alt={user.name ?? user.username}
                  width={96}
                  height={96}
                  className="rounded-full object-cover ring-2 ring-line"
                />
                <div>
                  <h1 className="text-3xl font-semibold tracking-tight text-ink">{user.name ?? user.username}</h1>
                  <p className="mt-1 text-muted">@{user.username}</p>
                  {user.bio ? <p className="mt-2 max-w-md text-sm leading-7 text-muted">{user.bio}</p> : null}
                </div>
              </div>

              {/* Stats + follow */}
              <div className="flex flex-col gap-4">
                <div className="flex gap-6 text-center">
                  <div>
                    <p className="text-2xl font-bold text-ink">{user._count.pins}</p>
                    <p className="text-xs text-muted">Pins</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink">{user._count.followers}</p>
                    <p className="text-xs text-muted">Followers</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink">{user._count.following}</p>
                    <p className="text-xs text-muted">Following</p>
                  </div>
                </div>

                {!isSelf && session?.user ? (
                  <FollowButton
                    targetUserId={user.id}
                    initialFollowing={isFollowing}
                    followerCount={user._count.followers}
                  />
                ) : isSelf ? (
                  <Link
                    href="/profile"
                    className="rounded-full border border-line bg-card px-5 py-2.5 text-center text-sm font-semibold text-ink hover:bg-surface"
                  >
                    Edit profile
                  </Link>
                ) : (
                  <Link
                    href="/auth/sign-in"
                    className="rounded-full bg-ink px-5 py-2.5 text-center text-sm font-semibold text-white"
                  >
                    Sign in to follow
                  </Link>
                )}
              </div>
            </div>
          </div>

          {/* Followers / Following mini lists */}
          {(followerUsers.length > 0 || followingUsers.length > 0) && (
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              {followerUsers.length > 0 && (
                <div className="rounded-[28px] border border-line bg-card p-6 shadow-soft">
                  <h2 className="mb-4 text-base font-semibold text-ink">Followers</h2>
                  <div className="flex flex-wrap gap-3">
                    {followerUsers.map(({ follower }) => (
                      <Link key={follower.id} href={`/user/${follower.username}`} className="flex items-center gap-2 rounded-full border border-line px-3 py-1.5 text-sm hover:bg-surface">
                        <Image
                          src={follower.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(follower.name ?? follower.username)}&size=64`}
                          alt={follower.name ?? follower.username}
                          width={24}
                          height={24}
                          className="rounded-full object-cover"
                        />
                        <span className="font-medium text-ink">@{follower.username}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
              {followingUsers.length > 0 && (
                <div className="rounded-[28px] border border-line bg-card p-6 shadow-soft">
                  <h2 className="mb-4 text-base font-semibold text-ink">Following</h2>
                  <div className="flex flex-wrap gap-3">
                    {followingUsers.map(({ following }) => (
                      <Link key={following.id} href={`/user/${following.username}`} className="flex items-center gap-2 rounded-full border border-line px-3 py-1.5 text-sm hover:bg-surface">
                        <Image
                          src={following.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(following.name ?? following.username)}&size=64`}
                          alt={following.name ?? following.username}
                          width={24}
                          height={24}
                          className="rounded-full object-cover"
                        />
                        <span className="font-medium text-ink">@{following.username}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* User's pins */}
          <section className="mt-10">
            <h2 className="mb-6 text-2xl font-semibold tracking-tight text-ink">
              {isSelf ? "My pins" : `${user.name ?? user.username}'s pins`}
            </h2>
            {userPins.length ? (
              <MasonryFeed items={userPins} />
            ) : (
              <EmptyState
                title="No pins yet"
                description="This user hasn't uploaded any pins."
                actionLabel="Explore pins"
                actionHref="/explore"
              />
            )}
          </section>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}

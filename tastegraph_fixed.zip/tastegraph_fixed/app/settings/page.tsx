import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Container } from "@/components/container"
import { SectionHeading } from "@/components/section-heading"
import { SettingsCard } from "@/components/settings-card"
import { authOptions } from "@/lib/auth"

export default async function SettingsPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect("/auth/sign-in?callbackUrl=/settings")

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <main className="py-12">
        <Container>
          <SectionHeading eyebrow="Settings" title="Account and product settings" description="Starter settings surface for the first public versions of the product." />
          <div className="grid gap-4 md:grid-cols-2">
            <SettingsCard title="Account" description={`Signed in as ${session.user.email ?? "unknown"}. Add email verification and password reset next.`} />
            <SettingsCard title="Personalization" description="In a future version, users should be able to tune discovery intensity, hide categories and reset their taste profile." />
            <SettingsCard title="Privacy" description="Add download/export of user data, account deletion and consent settings before wider launch." />
            <SettingsCard title="Notifications" description="Add email and push notification preferences once delivery channels exist." />
          </div>
        </Container>
      </main>
      <SiteFooter />
    </div>
  )
}
// Dark mode is handled globally via the ThemeToggle in the header.
// Users can switch between Light, Dark, and System modes from any page.

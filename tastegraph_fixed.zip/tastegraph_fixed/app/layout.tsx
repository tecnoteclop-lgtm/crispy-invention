import "./globals.css"
import type { Metadata } from "next"
import { AuthProvider } from "@/components/auth-provider"
import { ThemeProvider } from "@/components/theme-provider"

const base = process.env.APP_BASE_URL || "http://localhost:3000"

export const metadata: Metadata = {
  metadataBase: new URL(base),
  title: { default: "TasteGraph", template: "%s · TasteGraph" },
  description: "AI powered inspiration discovery platform starter",
  openGraph: {
    title: "TasteGraph",
    description: "AI powered inspiration discovery platform starter",
    url: base, siteName: "TasteGraph", type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "TasteGraph",
    description: "AI powered inspiration discovery platform starter",
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

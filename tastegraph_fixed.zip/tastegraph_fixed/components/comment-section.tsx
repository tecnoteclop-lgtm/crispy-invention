"use client"

import { useState, useEffect, useTransition, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { MessageCircle, Trash2, CornerDownRight, Loader2, Send } from "lucide-react"

interface Author {
  id: string
  username: string
  name: string | null
  image: string | null
}

interface CommentData {
  id: string
  body: string
  createdAt: string
  author: Author
  replies: Omit<CommentData, "replies">[]
}

interface Props {
  pinId: string
  currentUserId?: string
  currentUserRole?: string
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return "just now"
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  return `${Math.floor(h / 24)}d ago`
}

function Avatar({ author }: { author: Author }) {
  const src = author.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(author.name ?? author.username)}&size=64`
  return (
    <Link href={`/user/${author.username}`}>
      <Image src={src} alt={author.name ?? author.username} width={36} height={36} className="rounded-full object-cover ring-1 ring-line" />
    </Link>
  )
}

function CommentItem({
  comment,
  currentUserId,
  currentUserRole,
  onDelete,
  onReply,
}: {
  comment: CommentData
  currentUserId?: string
  currentUserRole?: string
  onDelete: (id: string) => void
  onReply: (id: string, username: string) => void
}) {
  const canDelete = currentUserId === comment.author.id || currentUserRole === "admin"

  return (
    <div className="flex gap-3">
      <Avatar author={comment.author} />
      <div className="flex-1">
        <div className="rounded-2xl bg-surface dark:bg-surface px-4 py-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Link href={`/user/${comment.author.username}`} className="text-sm font-semibold text-ink hover:underline">
                {comment.author.name ?? comment.author.username}
              </Link>
              <span className="text-xs text-muted/70">{timeAgo(comment.createdAt)}</span>
            </div>
            <div className="flex items-center gap-1">
              {currentUserId && (
                <button
                  onClick={() => onReply(comment.id, comment.author.username)}
                  className="flex items-center gap-1 rounded-full px-2 py-1 text-xs text-muted/70 hover:bg-line hover:text-ink"
                >
                  <CornerDownRight size={11} /> Reply
                </button>
              )}
              {canDelete && (
                <button
                  onClick={() => onDelete(comment.id)}
                  className="rounded-full p-1 text-muted/50 hover:text-red-500"
                  title="Delete comment"
                >
                  <Trash2 size={13} />
                </button>
              )}
            </div>
          </div>
          <p className="mt-1 text-sm leading-6 text-slate-700">{comment.body}</p>
        </div>

        {/* Replies */}
        {comment.replies?.length > 0 && (
          <div className="mt-2 flex flex-col gap-2 pl-4 border-l-2 border-line">
            {comment.replies.map((reply) => (
              <div key={reply.id} className="flex gap-3">
                <Avatar author={reply.author} />
                <div className="flex-1 rounded-2xl bg-surface px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Link href={`/user/${reply.author.username}`} className="text-sm font-semibold text-ink hover:underline">
                        {reply.author.name ?? reply.author.username}
                      </Link>
                      <span className="text-xs text-muted/70">{timeAgo(reply.createdAt)}</span>
                    </div>
                    {(currentUserId === reply.author.id || currentUserRole === "admin") && (
                      <button onClick={() => onDelete(reply.id)} className="rounded-full p-1 text-muted/50 hover:text-red-500">
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                  <p className="mt-1 text-sm leading-6 text-slate-700">{reply.body}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export function CommentSection({ pinId, currentUserId, currentUserRole }: Props) {
  const [comments, setComments] = useState<CommentData[]>([])
  const [loading, setLoading] = useState(true)
  const [text, setText] = useState("")
  const [replyTo, setReplyTo] = useState<{ id: string; username: string } | null>(null)
  const [isPending, startTransition] = useTransition()
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    fetch(`/api/comments?pinId=${pinId}`)
      .then((r) => r.json())
      .then((d) => { setComments(d.comments ?? []); setLoading(false) })
  }, [pinId])

  function handleReply(id: string, username: string) {
    setReplyTo({ id, username })
    setText(`@${username} `)
    inputRef.current?.focus()
  }

  function handleDelete(id: string) {
    startTransition(async () => {
      const res = await fetch(`/api/comments/${id}`, { method: "DELETE" })
      if (!res.ok) return
      setComments((prev) =>
        prev
          .filter((c) => c.id !== id)
          .map((c) => ({ ...c, replies: c.replies.filter((r) => r.id !== id) }))
      )
    })
  }

  function handleSubmit() {
    if (!text.trim()) return
    startTransition(async () => {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pinId, body: text.trim(), parentId: replyTo?.id }),
      })
      if (!res.ok) return
      const data = await res.json()
      if (replyTo) {
        setComments((prev) =>
          prev.map((c) =>
            c.id === replyTo.id ? { ...c, replies: [...(c.replies ?? []), data.comment] } : c
          )
        )
      } else {
        setComments((prev) => [...prev, { ...data.comment, replies: [] }])
      }
      setText("")
      setReplyTo(null)
    })
  }

  const total = comments.reduce((acc, c) => acc + 1 + (c.replies?.length ?? 0), 0)

  return (
    <section className="mt-10">
      <h2 className="mb-6 flex items-center gap-2 text-xl font-semibold text-ink">
        <MessageCircle size={20} className="text-brand" />
        Comments
        {total > 0 && <span className="rounded-full bg-surface px-2.5 py-0.5 text-sm font-normal text-muted">{total}</span>}
      </h2>

      {/* Comment input */}
      {currentUserId ? (
        <div className="mb-8 rounded-[24px] border border-line bg-card p-4 shadow-soft">
          {replyTo && (
            <div className="mb-2 flex items-center gap-2 text-xs text-muted/70">
              <CornerDownRight size={12} />
              Replying to <span className="font-medium text-brand">@{replyTo.username}</span>
              <button onClick={() => { setReplyTo(null); setText("") }} className="ml-auto text-muted/70 hover:text-ink">✕</button>
            </div>
          )}
          <textarea
            ref={inputRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSubmit() }}
            rows={2}
            maxLength={1000}
            placeholder="Write a comment… (Cmd+Enter to send)"
            className="w-full resize-none bg-transparent text-sm text-ink outline-none placeholder:text-muted/70"
          />
          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-muted/70">{text.length}/1000</span>
            <button
              onClick={handleSubmit}
              disabled={!text.trim() || isPending}
              className="flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-xs font-semibold text-white disabled:opacity-40"
            >
              {isPending ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
              {replyTo ? "Reply" : "Comment"}
            </button>
          </div>
        </div>
      ) : (
        <div className="mb-8 rounded-[24px] border border-line bg-card p-5 text-center text-sm text-muted">
          <Link href="/auth/sign-in" className="font-semibold text-brand hover:underline">Sign in</Link> to leave a comment.
        </div>
      )}

      {/* Comments list */}
      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 size={24} className="animate-spin text-muted/70" />
        </div>
      ) : comments.length === 0 ? (
        <p className="rounded-[24px] border border-line bg-card p-8 text-center text-sm text-muted/70">
          No comments yet. Be the first to share your thoughts!
        </p>
      ) : (
        <div className="flex flex-col gap-5">
          {comments.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              currentUserId={currentUserId}
              currentUserRole={currentUserRole}
              onDelete={handleDelete}
              onReply={handleReply}
            />
          ))}
        </div>
      )}
    </section>
  )
}

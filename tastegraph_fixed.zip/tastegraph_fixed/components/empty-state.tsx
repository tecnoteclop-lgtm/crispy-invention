import Link from "next/link"

export function EmptyState({
  title,
  description,
  actionLabel,
  actionHref,
}: {
  title: string
  description: string
  actionLabel?: string
  actionHref?: string
}) {
  return (
    <div className="rounded-[28px] border border-dashed border-line bg-card p-10 text-center shadow-soft">
      <h3 className="text-xl font-semibold text-ink">{title}</h3>
      <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-muted">{description}</p>
      {actionLabel && actionHref ? (
        <Link href={actionHref} className="mt-6 inline-flex rounded-full bg-ink px-5 py-3 text-sm font-medium text-white">
          {actionLabel}
        </Link>
      ) : null}
    </div>
  )
}

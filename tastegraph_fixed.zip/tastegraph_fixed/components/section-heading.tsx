export function SectionHeading({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return (
    <div className="mb-8">
      {eyebrow ? <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-brand">{eyebrow}</p> : null}
      <h2 className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">{title}</h2>
      {description ? <p className="mt-2 max-w-2xl text-muted">{description}</p> : null}
    </div>
  )
}

"use client"

import { useState, useTransition } from "react"
import { Heart, Loader2 } from "lucide-react"

interface Props {
  pinId: string
  initialLiked: boolean
  initialCount: number
}

export function LikeButton({ pinId, initialLiked, initialCount }: Props) {
  const [liked, setLiked] = useState(initialLiked)
  const [count, setCount] = useState(initialCount)
  const [isPending, startTransition] = useTransition()

  function toggle() {
    startTransition(async () => {
      const res = await fetch("/api/likes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pinId }),
      })
      if (!res.ok) return
      const data = await res.json()
      setLiked(data.liked)
      setCount(data.count)
    })
  }

  return (
    <button
      onClick={toggle}
      disabled={isPending}
      className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition disabled:opacity-50 ${
        liked
          ? "bg-red-50 text-red-500 hover:bg-red-100"
          : "border border-line bg-card text-muted hover:bg-surface"
      }`}
    >
      {isPending ? (
        <Loader2 size={15} className="animate-spin" />
      ) : (
        <Heart size={15} className={liked ? "fill-red-500" : ""} />
      )}
      <span>{count}</span>
    </button>
  )
}

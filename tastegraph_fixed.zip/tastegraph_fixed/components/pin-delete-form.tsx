"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"

export function PinDeleteForm({ pinId }: { pinId: string }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function onDelete() {
    const confirmed = window.confirm("Delete this pin?")
    if (!confirmed) return

    setLoading(true)
    setError("")
    const res = await fetch(`/api/pins/${pinId}`, { method: "DELETE" })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || "Could not delete pin.")
      return
    }

    router.push("/profile")
    router.refresh()
  }

  return (
    <div className="mt-4">
      <button disabled={loading} onClick={onDelete} className="rounded-full border border-line px-5 py-3 text-sm font-medium text-ink disabled:opacity-50">
        {loading ? "Deleting..." : "Delete pin"}
      </button>
      {error ? <p className="mt-3 text-sm text-red-600">{error}</p> : null}
    </div>
  )
}

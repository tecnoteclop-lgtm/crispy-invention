"use client"
import { signOut } from "next-auth/react"
export function SignOutButton() {
  return <button onClick={() => signOut({ callbackUrl: "/" })} className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-white">Sign out</button>
}

"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { PinCard } from "@/components/pin-card"
import { Loader2 } from "lucide-react"

type PinItem = {
  id: string
  title: string
  slug: string
  description: string
  imageUrl: string
  width: number
  height: number
  tags: string[]
  saveCount?: number
  author: { username: string; name: string; image: string | null }
}

interface Props {
  initialItems: PinItem[]
  query?: string
  tag?: string
  sortBy?: string
  initialHasMore: boolean
  initialCursor: string | null
}

export function InfiniteMasonryFeed({ initialItems, query, tag, sortBy, initialHasMore, initialCursor }: Props) {
  const [items, setItems]     = useState<PinItem[]>(initialItems)
  const [cursor, setCursor]   = useState<string | null>(initialCursor)
  const [hasMore, setHasMore] = useState(initialHasMore)
  const [loading, setLoading] = useState(false)
  const sentinelRef           = useRef<HTMLDivElement>(null)

  // Reset when search params change (user types a new query)
  useEffect(() => {
    setItems(initialItems)
    setCursor(initialCursor)
    setHasMore(initialHasMore)
  }, [initialItems, initialCursor, initialHasMore])

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (cursor)  params.set("cursor", cursor)
      if (query)   params.set("q",      query)
      if (tag)     params.set("tag",    tag)
      if (sortBy)  params.set("sort",   sortBy)

      const res  = await fetch(`/api/pins/feed?${params.toString()}`)
      const data = await res.json()
      if (!res.ok) return

      setItems((prev) => {
        const seen = new Set(prev.map((p) => p.id))
        return [...prev, ...(data.items as PinItem[]).filter((p) => !seen.has(p.id))]
      })
      setCursor(data.nextCursor)
      setHasMore(data.hasMore)
    } finally {
      setLoading(false)
    }
  }, [loading, hasMore, cursor, query, tag, sortBy])

  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) loadMore() },
      { rootMargin: "300px" }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [loadMore])

  if (items.length === 0 && !loading) return null

  return (
    <>
      <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 xl:columns-4">
        {items.map((pin) => <PinCard key={pin.id} pin={pin} />)}
      </div>

      <div ref={sentinelRef} className="mt-8 flex justify-center py-6">
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted/70">
            <Loader2 size={18} className="animate-spin" /> Loading more pins…
          </div>
        ) : !hasMore && items.length > 0 ? (
          <p className="text-sm text-muted/70">You've seen everything ✨</p>
        ) : null}
      </div>
    </>
  )
}

"use client"

import { FormEvent, useState } from "react"
import { useRouter } from "next/navigation"

export function SaveToggleForm({
  pinId,
  initialSaved = false,
  boardId = "",
}: {
  pinId: string
  initialSaved?: boolean
  boardId?: string
}) {
  const router = useRouter()
  const [saved, setSaved] = useState(initialSaved)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError("")
    const res = await fetch("/api/saves/toggle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        pinId,
        boardId: boardId || null,
      }),
    })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || "Could not update save state.")
      return
    }

    setSaved(Boolean(data.saved))
    router.refresh()
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-3">
      <button
        disabled={loading}
        className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white disabled:opacity-50"
      >
        {loading ? "Updating..." : saved ? "Unsave pin" : "Save pin"}
      </button>
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
    </form>
  )
}

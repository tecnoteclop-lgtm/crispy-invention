export function TasteProfileCard({ items }: { items?: Array<{ tag: string; weight: number }> }) {
  const traits = items && items.length ? items.slice(0, 6).map((item) => ({ label: item.tag, value: item.weight })) : [
    { label: "minimal", value: 92 }, { label: "warm", value: 84 }, { label: "editorial", value: 61 }, { label: "interior", value: 46 }
  ]
  return (
    <div className="rounded-[32px] border border-line bg-card p-6 shadow-soft">
      <div className="mb-5 flex items-center justify-between">
        <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">Taste DNA</p><h3 className="mt-2 text-2xl font-semibold text-ink">Your aesthetic profile</h3></div>
        <div className="rounded-full bg-surface px-3 py-1 text-xs font-medium text-muted">Beta</div>
      </div>
      <div className="space-y-4">{traits.map((trait) => <div key={trait.label}><div className="mb-2 flex items-center justify-between text-sm"><span className="font-medium text-ink">{trait.label}</span><span className="text-muted">{trait.value}%</span></div><div className="h-3 rounded-full bg-surface"><div className="h-3 rounded-full bg-gradient-to-r from-brand to-brand2" style={{ width: `${trait.value}%` }} /></div></div>)}</div>
      <p className="mt-5 text-sm leading-6 text-muted">This profile is derived from saved-pin tags in this starter version.</p>
    </div>
  )
}

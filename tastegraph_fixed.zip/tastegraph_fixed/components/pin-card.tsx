import Image from "next/image"
import Link from "next/link"

type PinCardType = {
  id: string; title: string; slug: string; description: string
  imageUrl: string; width: number; height: number; tags: string[]
  saveCount?: number; personalizedScore?: number
  author: { username: string; name: string; image: string | null }
}

export function PinCard({ pin }: { pin: PinCardType }) {
  return (
    <div className="mb-5 break-inside-avoid">
      <Link href={`/pin/${pin.slug}`} className="group block overflow-hidden rounded-[28px] border border-line bg-card shadow-soft transition hover:shadow-soft-dark">
        <div className="relative">
          <Image src={pin.imageUrl} alt={pin.title} width={pin.width} height={pin.height} className="h-auto w-full object-cover transition duration-300 group-hover:scale-[1.02]" />
          <button className="absolute right-4 top-4 rounded-full bg-ink px-4 py-2 text-sm font-medium text-canvas opacity-0 transition group-hover:opacity-100">Save</button>
        </div>
        <div className="p-4">
          <h3 className="text-base font-semibold text-ink">{pin.title}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-muted">{pin.description}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {pin.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="rounded-full bg-surface px-2 py-1 text-[11px] text-muted">{tag}</span>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Image
                src={pin.author.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(pin.author.name)}`}
                alt={pin.author.name} width={32} height={32}
                className="h-8 w-8 rounded-full object-cover ring-1 ring-line"
              />
              <div>
                <Link href={`/user/${pin.author.username}`} className="text-sm font-medium text-ink hover:underline">{pin.author.name}</Link>
                <p className="text-xs text-muted">@{pin.author.username}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted">{pin.saveCount ?? 0} saves</div>
              {typeof pin.personalizedScore === "number" && (
                <div className="text-[11px] text-brand">score {pin.personalizedScore}</div>
              )}
            </div>
          </div>
        </div>
      </Link>
    </div>
  )
}

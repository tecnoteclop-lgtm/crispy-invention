import { TagChip } from "@/components/tag-chip"
const categories = ["interior", "fashion", "branding", "travel", "food", "minimal", "typography", "ui design", "warm", "editorial"]
export function CategoryPills() {
  return <div className="flex flex-wrap gap-2">{categories.map((category) => <TagChip key={category} tag={category} />)}</div>
}

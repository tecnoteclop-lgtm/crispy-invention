"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"

export function AdminReportActions({
  reportId,
  currentStatus,
  pinId,
  pinHidden,
}: {
  reportId: string
  currentStatus: string
  pinId: string
  pinHidden: boolean
}) {
  const router = useRouter()
  const [status, setStatus] = useState(currentStatus)
  const [hidden, setHidden] = useState(pinHidden)
  const [loading, setLoading] = useState(false)

  async function updateReport(nextStatus: string) {
    setLoading(true)
    await fetch(`/api/moderation/report/${reportId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    })
    setStatus(nextStatus)
    setLoading(false)
    router.refresh()
  }

  async function togglePin() {
    setLoading(true)
    const nextHidden = !hidden
    await fetch(`/api/moderation/pin/${pinId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isHidden: nextHidden }),
    })
    setHidden(nextHidden)
    setLoading(false)
    router.refresh()
  }

  return (
    <div className="mt-4 flex flex-wrap gap-3">
      <button disabled={loading} onClick={() => updateReport("reviewing")} className="rounded-full border border-line px-4 py-2 text-sm">
        Reviewing
      </button>
      <button disabled={loading} onClick={() => updateReport("resolved")} className="rounded-full border border-line px-4 py-2 text-sm">
        Resolve
      </button>
      <button disabled={loading} onClick={() => updateReport("dismissed")} className="rounded-full border border-line px-4 py-2 text-sm">
        Dismiss
      </button>
      <button disabled={loading} onClick={togglePin} className="rounded-full bg-ink px-4 py-2 text-sm text-white">
        {hidden ? "Unhide pin" : "Hide pin"}
      </button>
      <span className="self-center text-xs text-muted">status: {status} · pin: {hidden ? "hidden" : "visible"}</span>
    </div>
  )
}

"use client"

import { useEffect } from "react"
import { track } from "@/lib/analytics-client"

export function PageTrack({ eventName, page }: { eventName: string; page: string }) {
  useEffect(() => {
    track(eventName, page)
  }, [eventName, page])

  return null
}

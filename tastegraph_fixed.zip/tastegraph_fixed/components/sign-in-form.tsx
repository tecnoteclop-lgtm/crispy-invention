"use client"
import { FormEvent, useState } from "react"
import { signIn } from "next-auth/react"
import { useRouter, useSearchParams } from "next/navigation"
export function SignInForm() {
  const router = useRouter()
  const params = useSearchParams()
  const callbackUrl = params.get("callbackUrl") || "/profile"
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setLoading(true); setError("")
    const formData = new FormData(event.currentTarget)
    const res = await signIn("credentials", { email: String(formData.get("email") || ""), password: String(formData.get("password") || ""), redirect: false, callbackUrl })
    setLoading(false)
    if (res?.error) { setError("Invalid email or password."); return }
    router.push(callbackUrl); router.refresh()
  }
  return (
    <form className="grid gap-4" onSubmit={onSubmit}>
      <input name="email" type="email" required className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="demo@tastegraph.app" />
      <input name="password" type="password" required className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="demo12345" />
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button disabled={loading} className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white disabled:opacity-50">{loading ? "Signing in..." : "Sign in"}</button>
    </form>
  )
}
// OAuth buttons are injected by the parent page — see app/auth/sign-in/page.tsx

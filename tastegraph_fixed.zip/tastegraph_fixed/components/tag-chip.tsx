import Link from "next/link"
export function TagChip({ tag, count }: { tag: string; count?: number }) {
  return <Link href={`/search?tag=${encodeURIComponent(tag)}`} className="rounded-full border border-line bg-card px-4 py-2 text-sm text-slate-700 transition hover:border-slate-300 hover:bg-surface">#{tag}{typeof count === "number" ? ` (${count})` : ""}</Link>
}

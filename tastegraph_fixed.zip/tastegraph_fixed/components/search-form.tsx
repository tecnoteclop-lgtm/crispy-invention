"use client"

import { useRouter, useSearchParams, usePathname } from "next/navigation"
import { useEffect, useRef, useState, useTransition } from "react"
import { Search, SlidersHorizontal, X, Tag, Loader2 } from "lucide-react"

const DEBOUNCE_MS = 350
const SORT_OPTIONS = [
  { value: "relevance", label: "Most relevant" },
  { value: "recent",    label: "Most recent"   },
  { value: "saves",     label: "Most saved"    },
]

export function SearchForm() {
  const router      = useRouter()
  const pathname    = usePathname()
  const params      = useSearchParams()
  const [, startTransition] = useTransition()

  const [q,       setQ]       = useState(params.get("q")    ?? "")
  const [tag,     setTag]     = useState(params.get("tag")  ?? "")
  const [sort,    setSort]    = useState(params.get("sort") ?? "relevance")
  const [showAdv, setShowAdv] = useState(!!(params.get("tag") || params.get("sort")))
  const [loading, setLoading] = useState(false)

  const debounceRef = useRef<ReturnType<typeof setTimeout>>()

  // Auto-submit on change with debounce
  useEffect(() => {
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      const next = new URLSearchParams()
      if (q.trim())   next.set("q",    q.trim())
      if (tag.trim()) next.set("tag",  tag.trim())
      if (sort !== "relevance") next.set("sort", sort)

      // Only navigate if something changed
      const current = new URLSearchParams(params.toString())
      if (next.toString() !== current.toString()) {
        setLoading(true)
        startTransition(() => {
          router.push(`/search?${next.toString()}`)
          setLoading(false)
        })
      }
    }, DEBOUNCE_MS)

    return () => clearTimeout(debounceRef.current)
  }, [q, tag, sort])

  function clear() {
    setQ(""); setTag(""); setSort("relevance")
    router.push("/search")
  }

  const hasFilters = q.trim() || tag.trim() || sort !== "relevance"

  return (
    <div className="rounded-[28px] border border-line bg-card p-5 shadow-soft">
      {/* Main search row */}
      <div className="flex items-center gap-3">
        <div className="flex flex-1 items-center gap-3 rounded-2xl border border-line bg-surface px-4 py-3">
          {loading
            ? <Loader2 size={16} className="shrink-0 animate-spin text-muted/70" />
            : <Search   size={16} className="shrink-0 text-muted/70" />
          }
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-muted/70"
            placeholder="Search titles, descriptions, tags…"
            autoFocus={pathname === "/search"}
          />
          {q && (
            <button onClick={() => setQ("")} className="shrink-0 text-muted/70 hover:text-ink">
              <X size={14} />
            </button>
          )}
        </div>

        {/* Advanced toggle */}
        <button
          onClick={() => setShowAdv((v) => !v)}
          className={`flex items-center gap-1.5 rounded-2xl border px-4 py-3 text-sm transition ${
            showAdv ? "border-brand bg-brand/5 text-brand" : "border-line text-muted hover:bg-surface"
          }`}
        >
          <SlidersHorizontal size={14} />
          <span className="hidden sm:inline">Filters</span>
          {(tag || sort !== "relevance") && (
            <span className="ml-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[9px] font-bold text-white">
              {(!!tag ? 1 : 0) + (sort !== "relevance" ? 1 : 0)}
            </span>
          )}
        </button>

        {/* Clear all */}
        {hasFilters && (
          <button onClick={clear} className="rounded-2xl border border-line px-4 py-3 text-sm text-muted hover:bg-surface">
            Clear
          </button>
        )}
      </div>

      {/* Advanced filters */}
      {showAdv && (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {/* Tag filter */}
          <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface px-4 py-3">
            <Tag size={14} className="shrink-0 text-muted/70" />
            <input
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted/70"
              placeholder="Filter by tag (e.g. typography)"
            />
            {tag && (
              <button onClick={() => setTag("")} className="shrink-0 text-muted/70 hover:text-ink">
                <X size={12} />
              </button>
            )}
          </div>

          {/* Sort */}
          <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface px-4 py-3">
            <SlidersHorizontal size={14} className="shrink-0 text-muted/70" />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="w-full bg-transparent text-sm text-ink outline-none"
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* Active filter chips */}
      {(tag || sort !== "relevance") && (
        <div className="mt-3 flex flex-wrap gap-2">
          {tag && (
            <span className="flex items-center gap-1.5 rounded-full bg-brand/10 px-3 py-1 text-xs font-medium text-brand">
              #{tag}
              <button onClick={() => setTag("")}><X size={10} /></button>
            </span>
          )}
          {sort !== "relevance" && (
            <span className="flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-muted">
              {SORT_OPTIONS.find((o) => o.value === sort)?.label}
              <button onClick={() => setSort("relevance")}><X size={10} /></button>
            </span>
          )}
        </div>
      )}
    </div>
  )
}

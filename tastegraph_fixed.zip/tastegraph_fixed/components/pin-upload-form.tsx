"use client"

import { ChangeEvent, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Upload, Link as LinkIcon, Tag, FileText, Type, X, CheckCircle } from "lucide-react"

type UploadStep = "image" | "details"

interface ImageMeta {
  url: string
  width: number
  height: number
}

export function PinUploadForm() {
  const router = useRouter()
  const [step, setStep] = useState<UploadStep>("image")
  const [imageMeta, setImageMeta] = useState<ImageMeta | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState("")

  // Details form state
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [tags, setTags] = useState("")
  const [sourceUrl, setSourceUrl] = useState("")
  const [tagInput, setTagInput] = useState("")
  const [tagList, setTagList] = useState<string[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")

  // ── Image upload via Cloudinary ───────────────────────────────────────────
  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      setUploadError("Please select an image file.")
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      setUploadError("Image must be under 10 MB.")
      return
    }

    setUploading(true)
    setUploadError("")

    try {
      const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME
      const uploadPreset = process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET

      if (!cloudName || !uploadPreset) {
        // Fallback: use the file as a local object URL for dev previews
        const localUrl = URL.createObjectURL(file)
        const img = new window.Image()
        img.onload = () => {
          setImageMeta({ url: localUrl, width: img.naturalWidth, height: img.naturalHeight })
          setStep("details")
          setUploading(false)
        }
        img.src = localUrl
        return
      }

      const formData = new FormData()
      formData.append("file", file)
      formData.append("upload_preset", uploadPreset)

      const res = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
        method: "POST",
        body: formData,
      })

      if (!res.ok) throw new Error("Upload failed")
      const data = await res.json()
      setImageMeta({ url: data.secure_url, width: data.width, height: data.height })
      setStep("details")
    } catch {
      setUploadError("Image upload failed. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  function handleUrlImage() {
    const url = (document.getElementById("image-url-input") as HTMLInputElement)?.value.trim()
    if (!url) return
    setUploadError("")
    const img = new window.Image()
    img.crossOrigin = "anonymous"
    img.onload = () => {
      setImageMeta({ url, width: img.naturalWidth || 800, height: img.naturalHeight || 600 })
      setStep("details")
    }
    img.onerror = () => setUploadError("Could not load image from that URL.")
    img.src = url
  }

  // ── Tag helpers ───────────────────────────────────────────────────────────
  function addTag() {
    const t = tagInput.trim().toLowerCase().replace(/[^a-z0-9-]/g, "")
    if (t && !tagList.includes(t) && tagList.length < 10) {
      const next = [...tagList, t]
      setTagList(next)
      setTags(next.join(","))
    }
    setTagInput("")
  }

  function removeTag(tag: string) {
    const next = tagList.filter((t) => t !== tag)
    setTagList(next)
    setTags(next.join(","))
  }

  // ── Submit ────────────────────────────────────────────────────────────────
  async function handleSubmit() {
    if (!imageMeta) return
    if (!title.trim()) { setError("Title is required."); return }
    if (!description.trim()) { setError("Description is required."); return }
    if (tagList.length === 0) { setError("Add at least one tag."); return }

    setSubmitting(true)
    setError("")

    const res = await fetch("/api/pins/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: title.trim(),
        description: description.trim(),
        imageUrl: imageMeta.url,
        width: imageMeta.width,
        height: imageMeta.height,
        tags,
        sourceUrl: sourceUrl.trim(),
      }),
    })

    const data = await res.json()
    setSubmitting(false)

    if (!res.ok) {
      setError(data.error || "Could not create pin.")
      return
    }

    router.push(`/pin/${data.pin.slug}`)
    router.refresh()
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 1: Image picker
  // ─────────────────────────────────────────────────────────────────────────
  if (step === "image") {
    return (
      <div className="grid gap-6">
        {/* Drag & drop / click upload */}
        <label className="group relative flex min-h-[280px] cursor-pointer flex-col items-center justify-center gap-4 rounded-[28px] border-2 border-dashed border-line bg-card transition hover:border-brand hover:bg-surface">
          <input type="file" accept="image/*" className="sr-only" onChange={handleFileChange} disabled={uploading} />
          {uploading ? (
            <div className="flex flex-col items-center gap-3">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-line border-t-brand" />
              <p className="text-sm text-muted">Uploading…</p>
            </div>
          ) : (
            <>
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-surface text-brand transition group-hover:bg-brand group-hover:text-white">
                <Upload size={28} />
              </div>
              <div className="text-center">
                <p className="text-base font-semibold text-ink">Click to upload an image</p>
                <p className="mt-1 text-sm text-muted/70">PNG, JPG, WEBP · max 10 MB</p>
              </div>
            </>
          )}
        </label>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="h-px flex-1 bg-line" />
          <span className="text-xs text-muted/70">or paste an image URL</span>
          <div className="h-px flex-1 bg-line" />
        </div>

        {/* URL input */}
        <div className="flex gap-2">
          <div className="flex flex-1 items-center gap-2 rounded-2xl border border-line bg-card px-4 py-3">
            <LinkIcon size={16} className="shrink-0 text-muted/70" />
            <input
              id="image-url-input"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted/70"
              placeholder="https://example.com/photo.jpg"
            />
          </div>
          <button
            onClick={handleUrlImage}
            className="rounded-2xl border border-line bg-card px-5 py-3 text-sm font-medium text-ink transition hover:bg-surface"
          >
            Use URL
          </button>
        </div>

        {uploadError ? (
          <p className="rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-600">{uploadError}</p>
        ) : null}
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 2: Details
  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="grid gap-6 md:grid-cols-[1fr_1.4fr]">
      {/* Preview */}
      <div className="flex flex-col gap-4">
        <div className="overflow-hidden rounded-[28px] border border-line bg-card shadow-soft">
          {imageMeta && (
            <Image
              src={imageMeta.url}
              alt="Preview"
              width={imageMeta.width}
              height={imageMeta.height}
              className="h-auto w-full object-cover"
              unoptimized
            />
          )}
        </div>
        <button
          onClick={() => { setStep("image"); setImageMeta(null) }}
          className="flex items-center justify-center gap-2 rounded-2xl border border-line bg-card px-4 py-3 text-sm text-muted transition hover:bg-surface"
        >
          <X size={14} /> Change image
        </button>
      </div>

      {/* Form */}
      <div className="flex flex-col gap-4">
        {/* Title */}
        <div className="flex items-start gap-3 rounded-2xl border border-line bg-card px-4 py-3">
          <Type size={16} className="mt-1 shrink-0 text-muted/70" />
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            className="w-full bg-transparent text-sm font-medium text-ink outline-none placeholder:font-normal placeholder:text-muted/70"
            placeholder="Give your pin a title…"
          />
          <span className="shrink-0 text-xs text-muted/50">{title.length}/120</span>
        </div>

        {/* Description */}
        <div className="flex items-start gap-3 rounded-2xl border border-line bg-card px-4 py-3">
          <FileText size={16} className="mt-1 shrink-0 text-muted/70" />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={1000}
            rows={4}
            className="w-full resize-none bg-transparent text-sm text-ink outline-none placeholder:text-muted/70"
            placeholder="What's this pin about? Add context, mood, or story…"
          />
          <span className="shrink-0 text-xs text-muted/50">{description.length}/1000</span>
        </div>

        {/* Tags */}
        <div className="rounded-2xl border border-line bg-card px-4 py-3">
          <div className="flex items-center gap-2">
            <Tag size={16} className="shrink-0 text-muted/70" />
            <input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTag() } }}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted/70"
              placeholder="Add tags (press Enter or comma)"
              disabled={tagList.length >= 10}
            />
            <button
              onClick={addTag}
              disabled={!tagInput.trim() || tagList.length >= 10}
              className="rounded-full bg-brand px-3 py-1 text-xs font-medium text-white disabled:opacity-40"
            >
              Add
            </button>
          </div>
          {tagList.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {tagList.map((tag) => (
                <span key={tag} className="flex items-center gap-1 rounded-full bg-surface px-3 py-1 text-xs font-medium text-muted">
                  #{tag}
                  <button onClick={() => removeTag(tag)} className="ml-1 text-muted/70 hover:text-red-500">
                    <X size={10} />
                  </button>
                </span>
              ))}
            </div>
          )}
          <p className="mt-2 text-xs text-muted/70">{tagList.length}/10 tags</p>
        </div>

        {/* Source URL (optional) */}
        <div className="flex items-center gap-3 rounded-2xl border border-line bg-card px-4 py-3">
          <LinkIcon size={16} className="shrink-0 text-muted/70" />
          <input
            value={sourceUrl}
            onChange={(e) => setSourceUrl(e.target.value)}
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted/70"
            placeholder="Source URL (optional)"
            type="url"
          />
        </div>

        {error ? (
          <p className="rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-600">{error}</p>
        ) : null}

        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="flex items-center justify-center gap-2 rounded-full bg-ink px-6 py-4 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50"
        >
          {submitting ? (
            <>
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              Publishing…
            </>
          ) : (
            <>
              <CheckCircle size={16} />
              Publish pin
            </>
          )}
        </button>
      </div>
    </div>
  )
}

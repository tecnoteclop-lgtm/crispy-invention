import Link from "next/link"
export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-card">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-10 text-sm text-muted md:flex-row md:items-center md:justify-between md:px-6">
        <p>© 2026 TasteGraph. Built for global inspiration discovery.</p>
        <div className="flex gap-4"><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link><Link href="/report">Report</Link></div>
      </div>
    </footer>
  )
}

import Link from "next/link"
import { getServerSession } from "next-auth"
import { Search, PlusCircle, Settings, Shield } from "lucide-react"
import { authOptions } from "@/lib/auth"
import { Logo } from "@/components/logo"
import { SignOutButton } from "@/components/sign-out-button"
import { NotificationBell } from "@/components/notification-bell"
import { ThemeToggle } from "@/components/theme-toggle"

export async function SiteHeader() {
  const session = await getServerSession(authOptions)
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-card/80 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 md:px-6">
        <Logo />
        <nav className="hidden items-center gap-5 md:flex">
          <Link href="/explore"       className="text-sm text-muted transition hover:text-ink">Explore</Link>
          <Link href="/for-you"       className="text-sm text-muted transition hover:text-ink">For You</Link>
          <Link href="/search"        className="text-sm text-muted transition hover:text-ink">Search</Link>
          <Link href="/trending"      className="text-sm text-muted transition hover:text-ink">Trending</Link>
          <Link href="/following"     className="text-sm text-muted transition hover:text-ink">Following</Link>
          <Link href="/taste-profile" className="text-sm text-muted transition hover:text-ink">Taste DNA</Link>
          <Link href="/settings"      className="text-sm text-muted transition hover:text-ink">Settings</Link>
          {session?.user?.role === "admin" && (
            <Link href="/admin" className="flex items-center gap-1 text-sm text-muted transition hover:text-ink">
              <Shield size={14} /> Admin
            </Link>
          )}
        </nav>

        {/* Search hint */}
        <div className="ml-auto hidden max-w-md flex-1 items-center gap-2 rounded-full border border-line bg-surface px-4 py-2 md:flex">
          <Search size={16} className="text-muted" />
          <span className="w-full cursor-pointer text-sm text-muted" onClick={() => {}}>Search pins…</span>
        </div>

        {/* Right actions */}
        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <ThemeToggle />

          <Link href="/upload" className="rounded-full border border-line bg-card p-2 text-muted hover:bg-surface" aria-label="Upload pin">
            <PlusCircle size={18} />
          </Link>
          <Link href="/settings" className="rounded-full border border-line bg-card p-2 text-muted hover:bg-surface" aria-label="Settings">
            <Settings size={18} />
          </Link>

          {session?.user ? <NotificationBell /> : null}

          {session?.user ? (
            <>
              <Link href="/profile" className="rounded-full border border-line bg-card px-4 py-2 text-sm font-medium text-ink hover:bg-surface">
                {session.user.name ?? "Profile"}
              </Link>
              <SignOutButton />
            </>
          ) : (
            <Link href="/auth/sign-in" className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-canvas">
              Sign in
            </Link>
          )}
        </div>
      </div>
    </header>
  )
}

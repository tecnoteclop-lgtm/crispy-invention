"use client"

import { FormEvent, useState } from "react"
import { useRouter } from "next/navigation"

export function ProfileEditForm({
  initialName,
  initialBio,
  initialImage,
}: {
  initialName: string
  initialBio: string
  initialImage: string
}) {
  const router = useRouter()
  const [name, setName] = useState(initialName)
  const [bio, setBio] = useState(initialBio)
  const [image, setImage] = useState(initialImage)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setMessage("")
    setError("")

    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, bio, image }),
    })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || "Could not update profile.")
      return
    }

    setMessage("Profile updated.")
    router.refresh()
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4 rounded-[28px] border border-line bg-card p-6 shadow-soft">
      <h3 className="text-lg font-semibold text-ink">Edit profile</h3>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="rounded-2xl border border-line px-4 py-3 outline-none"
        placeholder="Name"
      />
      <input
        value={image}
        onChange={(e) => setImage(e.target.value)}
        className="rounded-2xl border border-line px-4 py-3 outline-none"
        placeholder="Avatar image URL"
      />
      <textarea
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        className="min-h-[120px] rounded-2xl border border-line px-4 py-3 outline-none"
        placeholder="Bio"
      />
      {message ? <p className="text-sm text-emerald-700">{message}</p> : null}
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button disabled={loading} className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white disabled:opacity-50">
        {loading ? "Saving..." : "Save changes"}
      </button>
    </form>
  )
}

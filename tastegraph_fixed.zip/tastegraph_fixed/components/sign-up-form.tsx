"use client"
import { FormEvent, useState } from "react"
import { useRouter } from "next/navigation"
export function SignUpForm() {
  const router = useRouter()
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setError("")
    const formData = new FormData(event.currentTarget)
    const res = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      name: String(formData.get("name") || ""),
      username: String(formData.get("username") || ""),
      email: String(formData.get("email") || ""),
      password: String(formData.get("password") || ""),
    })})
    const data = await res.json(); setLoading(false)
    if (!res.ok) { setError(data.error || "Could not create account."); return }
    router.push("/auth/sign-in"); router.refresh()
  }
  return (
    <form className="grid gap-4" onSubmit={onSubmit}>
      <input name="name" required className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="Your name" />
      <input name="email" type="email" required className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="you@example.com" />
      <input name="username" required className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="yourhandle" />
      <input name="password" type="password" required minLength={8} className="rounded-2xl border border-line px-4 py-3 outline-none" placeholder="Create a strong password" />
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button disabled={loading} className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white disabled:opacity-50">{loading ? "Creating..." : "Create account"}</button>
    </form>
  )
}

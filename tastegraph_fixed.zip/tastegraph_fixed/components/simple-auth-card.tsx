import { ReactNode } from "react"
import { Logo } from "@/components/logo"
export function AuthCard({ title, description, children }: { title: string; description: string; children: ReactNode }) {
  return <div className="mx-auto w-full max-w-md rounded-[32px] border border-line bg-card p-8 shadow-soft"><div className="mb-8"><Logo /><h1 className="mt-6 text-3xl font-semibold tracking-tight text-ink">{title}</h1><p className="mt-2 text-muted">{description}</p></div>{children}</div>
}

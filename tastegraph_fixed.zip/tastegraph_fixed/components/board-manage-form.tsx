"use client"

import { FormEvent, useState } from "react"
import { useRouter } from "next/navigation"

export function BoardManageForm({
  boardId,
  initialName,
  initialDescription,
}: {
  boardId: string
  initialName: string
  initialDescription: string
}) {
  const router = useRouter()
  const [name, setName] = useState(initialName)
  const [description, setDescription] = useState(initialDescription)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setMessage("")
    setError("")

    const res = await fetch(`/api/boards/${boardId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, description }),
    })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || "Could not update board.")
      return
    }

    setMessage("Board updated.")
    router.refresh()
  }

  async function onDelete() {
    const confirmed = window.confirm("Delete this board?")
    if (!confirmed) return

    setLoading(true)
    setMessage("")
    setError("")
    const res = await fetch(`/api/boards/${boardId}`, { method: "DELETE" })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || "Could not delete board.")
      return
    }

    router.push("/profile")
    router.refresh()
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4 rounded-[28px] border border-line bg-card p-6 shadow-soft">
      <h3 className="text-lg font-semibold text-ink">Manage board</h3>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="rounded-2xl border border-line px-4 py-3 outline-none"
        placeholder="Board name"
      />
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="min-h-[120px] rounded-2xl border border-line px-4 py-3 outline-none"
        placeholder="Description"
      />
      {message ? <p className="text-sm text-emerald-700">{message}</p> : null}
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <div className="flex gap-3">
        <button disabled={loading} className="rounded-full bg-ink px-5 py-3 text-sm font-medium text-white disabled:opacity-50">
          {loading ? "Saving..." : "Save board"}
        </button>
        <button type="button" disabled={loading} onClick={onDelete} className="rounded-full border border-line px-5 py-3 text-sm font-medium text-ink disabled:opacity-50">
          Delete board
        </button>
      </div>
    </form>
  )
}

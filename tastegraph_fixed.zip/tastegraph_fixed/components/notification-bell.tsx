"use client"

import { useState, useEffect, useRef, useTransition } from "react"
import Link from "next/link"
import Image from "next/image"
import { Bell, Heart, MessageCircle, UserPlus, Bookmark, Loader2, CheckCheck } from "lucide-react"

interface Actor {
  id: string
  username: string
  name: string | null
  image: string | null
}

interface NotifData {
  id: string
  type: "like" | "comment" | "reply" | "follow" | "save"
  read: boolean
  createdAt: string
  message: string | null
  pinId: string | null
  actor: Actor
}

const TYPE_ICON: Record<NotifData["type"], React.ReactNode> = {
  like:    <Heart    size={13} className="text-red-500"    />,
  comment: <MessageCircle size={13} className="text-blue-500"  />,
  reply:   <MessageCircle size={13} className="text-indigo-500"/>,
  follow:  <UserPlus size={13} className="text-emerald-500"/>,
  save:    <Bookmark size={13} className="text-amber-500"  />,
}

const TYPE_LABEL: Record<NotifData["type"], string> = {
  like:    "liked your pin",
  comment: "commented on your pin",
  reply:   "replied to your comment",
  follow:  "started following you",
  save:    "saved your pin",
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return "just now"
  if (m < 60) return `${m}m`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h`
  return `${Math.floor(h / 24)}d`
}

export function NotificationBell() {
  const [open, setOpen] = useState(false)
  const [notifications, setNotifications] = useState<NotifData[]>([])
  const [unread, setUnread] = useState(0)
  const [loaded, setLoaded] = useState(false)
  const [isPending, startTransition] = useTransition()
  const ref = useRef<HTMLDivElement>(null)

  // Close on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [])

  // Fetch on open
  useEffect(() => {
    if (!open || loaded) return
    fetch("/api/notifications")
      .then((r) => r.json())
      .then((d) => {
        setNotifications(d.notifications ?? [])
        setUnread(d.unreadCount ?? 0)
        setLoaded(true)
      })
  }, [open, loaded])

  // Poll every 60s for badge count
  useEffect(() => {
    const poll = () =>
      fetch("/api/notifications")
        .then((r) => r.json())
        .then((d) => setUnread(d.unreadCount ?? 0))
        .catch(() => {})
    const id = setInterval(poll, 60_000)
    poll()
    return () => clearInterval(id)
  }, [])

  function markAllRead() {
    startTransition(async () => {
      await fetch("/api/notifications", { method: "PATCH" })
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
      setUnread(0)
    })
  }

  async function markOneRead(id: string) {
    await fetch(`/api/notifications/${id}`, { method: "PATCH" })
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
    setUnread((c) => Math.max(0, c - 1))
  }

  function notifLink(n: NotifData) {
    if (n.type === "follow") return `/user/${n.actor.username}`
    if (n.pinId) return `/pin/${n.pinId}`
    return "#"
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-full border border-line p-2 text-muted hover:bg-surface"
        aria-label="Notifications"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-12 z-50 w-80 overflow-hidden rounded-[24px] border border-line bg-card shadow-xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <h3 className="text-sm font-semibold text-ink">Notifications</h3>
            {unread > 0 && (
              <button
                onClick={markAllRead}
                disabled={isPending}
                className="flex items-center gap-1 text-xs text-brand hover:underline disabled:opacity-50"
              >
                {isPending ? <Loader2 size={11} className="animate-spin" /> : <CheckCheck size={11} />}
                Mark all read
              </button>
            )}
          </div>

          {/* List */}
          <div className="max-h-[420px] overflow-y-auto">
            {!loaded ? (
              <div className="flex justify-center py-8">
                <Loader2 size={20} className="animate-spin text-muted/70" />
              </div>
            ) : notifications.length === 0 ? (
              <p className="py-10 text-center text-sm text-muted/70">No notifications yet.</p>
            ) : (
              notifications.map((n) => (
                <Link
                  key={n.id}
                  href={notifLink(n)}
                  onClick={() => { if (!n.read) markOneRead(n.id); setOpen(false) }}
                  className={`flex items-start gap-3 px-4 py-3 transition hover:bg-surface ${!n.read ? "bg-brand/5" : ""}`}
                >
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <Image
                      src={n.actor.image ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(n.actor.name ?? n.actor.username)}&size=64`}
                      alt={n.actor.name ?? n.actor.username}
                      width={36}
                      height={36}
                      className="rounded-full object-cover"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-card ring-1 ring-line">
                      {TYPE_ICON[n.type]}
                    </span>
                  </div>

                  {/* Text */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm leading-5 text-ink">
                      <span className="font-semibold">{n.actor.name ?? n.actor.username}</span>{" "}
                      {TYPE_LABEL[n.type]}
                      {n.message ? <span className="text-muted"> — "{n.message}"</span> : null}
                    </p>
                    <p className="mt-0.5 text-xs text-muted/70">{timeAgo(n.createdAt)}</p>
                  </div>

                  {/* Unread dot */}
                  {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" />}
                </Link>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  )
}

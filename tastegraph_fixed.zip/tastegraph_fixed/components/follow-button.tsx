"use client"

import { useState, useTransition } from "react"
import { UserPlus, UserCheck, Loader2 } from "lucide-react"

interface Props {
  targetUserId: string
  initialFollowing: boolean
  followerCount: number
}

export function FollowButton({ targetUserId, initialFollowing, followerCount }: Props) {
  const [following, setFollowing] = useState(initialFollowing)
  const [count, setCount] = useState(followerCount)
  const [isPending, startTransition] = useTransition()

  function toggle() {
    startTransition(async () => {
      const res = await fetch("/api/follow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetUserId }),
      })
      if (!res.ok) return
      const data = await res.json()
      setFollowing(data.following)
      setCount((c) => c + (data.following ? 1 : -1))
    })
  }

  return (
    <div className="flex items-center gap-3">
      <button
        onClick={toggle}
        disabled={isPending}
        className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition ${
          following
            ? "border border-line bg-card text-ink hover:bg-red-50 hover:text-red-600 hover:border-red-200"
            : "bg-ink text-white hover:opacity-90"
        } disabled:opacity-50`}
      >
        {isPending ? (
          <Loader2 size={15} className="animate-spin" />
        ) : following ? (
          <UserCheck size={15} />
        ) : (
          <UserPlus size={15} />
        )}
        {following ? "Following" : "Follow"}
      </button>
      <span className="text-sm text-muted">
        <strong className="text-ink">{count}</strong> followers
      </span>
    </div>
  )
}

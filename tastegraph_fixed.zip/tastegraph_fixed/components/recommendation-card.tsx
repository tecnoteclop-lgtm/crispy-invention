type RecommendationReason = { title: string; description: string }
export function RecommendationCard({ item }: { item: RecommendationReason }) {
  return <div className="rounded-[28px] border border-line bg-card p-6 shadow-soft"><p className="text-sm font-semibold text-ink">{item.title}</p><p className="mt-2 text-sm leading-6 text-muted">{item.description}</p></div>
}

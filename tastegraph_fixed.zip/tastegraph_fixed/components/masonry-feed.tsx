import { PinCard } from "@/components/pin-card"
type PinType = { id: string; title: string; slug: string; description: string; imageUrl: string; width: number; height: number; tags: string[]; saveCount?: number; personalizedScore?: number; author: { username: string; name: string; image: string } }
export function MasonryFeed({ items }: { items: PinType[] }) {
  return <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 xl:columns-4">{items.map((pin) => <PinCard key={pin.id} pin={pin} />)}</div>
}

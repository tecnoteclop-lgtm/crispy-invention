"use client"

import { useTheme } from "next-themes"
import { useEffect, useState } from "react"
import { Sun, Moon, Monitor } from "lucide-react"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Avoid hydration mismatch — only render after mount
  useEffect(() => setMounted(true), [])
  if (!mounted) return <div className="h-9 w-9 rounded-full border border-line bg-card" />

  const options = [
    { value: "light",  Icon: Sun,     label: "Light"  },
    { value: "dark",   Icon: Moon,    label: "Dark"   },
    { value: "system", Icon: Monitor, label: "System" },
  ] as const

  return (
    <div className="flex items-center gap-0.5 rounded-full border border-line bg-surface p-1">
      {options.map(({ value, Icon, label }) => (
        <button
          key={value}
          onClick={() => setTheme(value)}
          title={label}
          className={`flex h-7 w-7 items-center justify-center rounded-full text-sm transition ${
            theme === value
              ? "bg-card text-brand shadow-soft"
              : "text-muted hover:text-ink"
          }`}
        >
          <Icon size={14} />
        </button>
      ))}
    </div>
  )
}

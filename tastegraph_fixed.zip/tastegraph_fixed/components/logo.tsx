import Link from "next/link"
export function Logo() {
  return <Link href="/" className="text-xl font-bold tracking-tight">Taste<span className="text-brand">Graph</span></Link>
}

import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"
const prisma = new PrismaClient()

async function main() {
  const password = await bcrypt.hash("demo12345", 10)
  const demo = await prisma.user.upsert({
    where: { email: "demo@tastegraph.app" },
    update: {},
    create: {
      email: "demo@tastegraph.app",
      username: "demo",
      name: "Demo Creator",
      bio: "Visual curator across interiors, fashion and branding.",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80",
      password,
      role: "admin",
    },
  })

  const pins = [
    ["Japandi Living Room","japandi-living-room","Warm wood, low furniture and soft neutrals for a calm modern home.","https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80",800,1100,"japandi, interior, living room, minimal, warm"],
    ["Soft Editorial Fashion","soft-editorial-fashion","A soft luxury outfit direction with light layers and strong silhouette balance.","https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80",800,1200,"fashion, editorial, minimal, soft luxury"],
    ["Clean Brand Identity","clean-brand-identity","Typography-led identity system for a premium lifestyle brand.","https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80",800,980,"branding, graphic design, identity, typography"],
    ["Coastal Escape Hotel","coastal-escape-hotel","Mediterranean boutique hotel mood with texture, light and soft whites.","https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=1200&q=80",800,1260,"travel, hotel, mediterranean, interior, warm"],
    ["Monochrome UI System","monochrome-ui-system","A product system with bold contrast and calm spacing.","https://images.unsplash.com/photo-1516387938699-a93567ec168e?auto=format&fit=crop&w=1200&q=80",800,920,"ui design, design system, product, minimal"],
    ["Modern Table Story","modern-table-story","Styled dining inspiration with contrast plates, stone and citrus tones.","https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1200&q=80",800,1180,"food, table styling, hosting, warm"],
    ["Brutalist Concrete Escape","brutalist-concrete-escape","Architectural travel inspiration with sculptural forms and dramatic scale.","https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1200&q=80",800,1260,"architecture, travel, brutalist, concrete, minimal"],
    ["Quiet Workspace Setup","quiet-workspace-setup","A calm desk setup with neutrals, clean lines and focus-first composition.","https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80",800,1050,"workspace, minimal, productivity, interior"],
  ]

  const createdPins = []
  for (const [title, slug, description, imageUrl, width, height, tags] of pins) {
    const created = await prisma.pin.upsert({
      where: { slug },
      update: {},
      create: { title, slug, description, imageUrl, width, height, tags, authorId: demo.id },
    })
    createdPins.push(created)
  }

  const board = await prisma.board.upsert({
    where: { slug: "minimal-interiors" },
    update: {},
    create: {
      name: "Minimal Interiors",
      slug: "minimal-interiors",
      description: "Quiet rooms, calm palettes, texture-first spaces.",
      coverImage: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80",
      ownerId: demo.id,
    },
  })

  const savedSlugs = new Set(["japandi-living-room", "coastal-escape-hotel", "quiet-workspace-setup", "monochrome-ui-system"])
  for (const pin of createdPins) {
    if (!savedSlugs.has(pin.slug)) continue
    await prisma.save.upsert({
      where: { userId_pinId_boardId: { userId: demo.id, pinId: pin.id, boardId: board.id } },
      update: {},
      create: { userId: demo.id, pinId: pin.id, boardId: board.id },
    })
  }

  await prisma.analyticsEvent.createMany({
    data: [
      { eventName: "page_view", page: "/" },
      { eventName: "page_view", page: "/for-you", userId: demo.id },
      { eventName: "pin_view", page: "/pin/japandi-living-room", userId: demo.id, meta: JSON.stringify({ slug: "japandi-living-room" }) },
    ]
  }).catch(() => {})

  console.log("Seed completed. Demo login: demo@tastegraph.app / demo12345")
}
main().finally(async () => await prisma.$disconnect())

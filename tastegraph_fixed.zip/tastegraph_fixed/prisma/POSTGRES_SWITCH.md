# Switching Prisma to PostgreSQL

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

Then run:

```bash
npx prisma migrate dev --name init_postgres
npx prisma generate
```

For production:

```bash
npx prisma migrate deploy
npx prisma generate
```
